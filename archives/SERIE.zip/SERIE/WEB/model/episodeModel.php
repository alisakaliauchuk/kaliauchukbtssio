<?php
// Fichier : episodeModel.php
// Rôle : fonctions pour récupérer un épisode

require_once 'connexionBDD.php';

// Récupère les infos d'un épisode spécifique
// Retourne un tableau associatif ou false
function getInfoEpisode($numSerie, $numSaison, $numEpi) {
    $pdo = connexionBDD();
    $req = $pdo->prepare('
        SELECT e.num_epi, e.num_saison, e.num_serie,
               e.titre_vo, e.titre_vf, e.resume_epi,
               s.titre_serievf
        FROM Episode e
        JOIN Serie s ON e.num_serie = s.num_serie
        WHERE e.num_serie  = :num_serie
          AND e.num_saison = :num_saison
          AND e.num_epi    = :num_epi
    ');
    $req->execute([
        ':num_serie'  => $numSerie,
        ':num_saison' => $numSaison,
        ':num_epi'    => $numEpi
    ]);
    return $req->fetch();
}
