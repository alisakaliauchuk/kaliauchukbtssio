create database cartouche;
create role cartouche_admin password 'admin' login;
grant all on database cartouche to cartouche_admin;

create role cartouche_util login password 'util';
grant select on vue_client_facture to cartouche_util;
grant select on vue_detail_facture to cartouche_util;