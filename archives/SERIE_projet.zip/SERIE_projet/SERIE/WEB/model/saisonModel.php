<?php
require_once 'connexionBDD.php';

function getSaisonsDeSerie($numSerie) {
    $pdo = connexionBDD();
    $req = $pdo->prepare('SELECT num_saison, date_debut_tournage, date_fin_tournage
        FROM Saison
        WHERE num_serie = :num_serie
        ORDER BY num_saison');
    $req->execute([':num_serie' => $numSerie]);
    return $req->fetchAll();
}

function getEpisodesDeSaison($numSerie, $numSaison) {
    $pdo = connexionBDD();
    $req = $pdo->prepare('SELECT num_epi, num_saison, num_serie 
    FROM Episode 
    WHERE num_serie  = :num_serie AND num_saison = :num_saison 
    ORDER BY num_epi');
    $req->execute([':num_serie' => $numSerie, ':num_saison' => $numSaison]);
    return $req->fetchAll();
}
