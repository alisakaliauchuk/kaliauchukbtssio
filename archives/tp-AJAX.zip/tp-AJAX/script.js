//  script.js — à compléter
//  TP AJAX – Annuaire dynamique – BTS SIO SLAM
// --------------------------------------------------------------------------------------


//  Etape 1 — Sélectionner les éléments du DOM

//  Récupérez les deux éléments HTML dont vous aurez besoin :
//    • Le champ de saisie  → id="champRecherche"
//    • La liste dropdown   → id="liste-resultats"

const champRecherche = /* ??? récupérez l'élément par son id */;
const listeResultats = /* ??? récupérez l'élément par son id */;


// --------------------------------------------------------------------------------------
//  ÉTAPE 2 — Écouter la frappe de l'utilisateur
//
//  L'événement 'input' se déclenche à chaque caractère
//  tapé ou effacé dans le champ.
//  Branchez-le sur champRecherche pour appeler lancerRecherche().


/* ??? ajoutez l'écouteur ici */;


// --------------------------------------------------------------------------------------
//  ÉTAPE 3 — Écrire la fonction lancerRecherche()
//
//  Elle doit :
//    a) Lire la valeur du champ (sans espaces inutiles)
//    b) Si < 2 caractères → viderListe() et return
//    c) Construire l'URL : 'recherche.php?q=' + encodeURIComponent(saisie)
//    d) Créer un XMLHttpRequest
//    e) Ouvrir en GET, asynchrone (true)
//    f) Définir onreadystatechange :
//         readyState === 4 && status === 200 → afficherResultats( JSON.parse(xhr.responseText) )
//         readyState === 4 && status !== 200 → afficher une erreur dans listeResultats
//    g) Envoyer avec xhr.send()


function lancerRecherche() {

    // a) Lire et nettoyer la saisie
    const saisie = /* ??? */;

    // b) Moins de 2 caractères → on vide et on s'arrête
    if (/* ??? */) {
        viderListe();
        return;
    }

    // c) Construction de l'URL avec paramètre GET
    const url = /* ??? */;

    // d) Créer l'objet XMLHttpRequest
    const xhr = /* ??? */;

    // e) Configurer : méthode GET, URL, true = asynchrone
    xhr.open(/* ??? */, /* ??? */, /* ??? */);

    // f) Callback déclenché à chaque changement d'état de la requête
    xhr.onreadystatechange = function () {

        if (/* ??? requête terminée ET succès */) {

            // Convertir la réponse JSON (texte) en tableau JavaScript
            const personnes = /* ??? */;

            // Afficher les résultats dans la liste
            afficherResultats(personnes);

        } else if (/* ??? requête terminée mais erreur serveur */) {

            listeResultats.style.display = 'block';
            listeResultats.innerHTML = '<div class="erreur-ajax">Erreur serveur (' + xhr.status + ').</div>';
        }
    };

    // g) Envoyer la requête
    /* ??? */;
}


// --------------------------------------------------------------------------------------
//  ÉTAPE 4a — Écrire la fonction viderListe()
//
//  Elle doit vider le contenu de listeResultats
//  et le masquer (style.display = 'none')


function viderListe() {
    /* ??? */
}


// --------------------------------------------------------------------------------------
//  ÉTAPE 4b — Écrire la fonction afficherResultats(personnes)
//
//  Elle reçoit un tableau d'objets :
//  [{ prenom: "Marie", nom: "Dupont", service: "Informatique" }, ...]
//
//  Elle doit :
//    1. Vider la liste (listeResultats.innerHTML = '')
//    2. Si le tableau est vide → viderListe() et return
//    3. Rendre la liste visible (style.display = 'block')
//    4. Pour chaque personne, créer et injecter :
//
//       <div class="suggestion">
//         <span class="nom-complet">DUPONT Marie</span>
//         <span class="service">Informatique</span>
//       </div>
//
//    Note : affichez le nom en MAJUSCULES et le prénom normal
//           → p.nom.toUpperCase() + ' ' + p.prenom


function afficherResultats(personnes) {

    // 1. Vider
    listeResultats.innerHTML = '';

    // 2. Tableau vide
    if (/* ??? */) {
        viderListe();
        return;
    }

    // 3. Afficher le conteneur
    listeResultats.style.display = /* ??? */;

    // 4. Créer une suggestion par personne
    personnes.forEach(function (p) {

        const div = document.createElement('div');
        div.className = /* ??? */;

        div.innerHTML = /* ??? en utilisant p.nom, p.prenom, p.service */;

        listeResultats.appendChild(div);
    });
}
