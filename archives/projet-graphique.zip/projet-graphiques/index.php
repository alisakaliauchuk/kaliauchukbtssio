<?php
/*
critères pour évaluer les bibliothèques de graphes :

- les fonctionnalités (les types de graphes, zoom ?, ...)
- la licence (libre, payant?)
- l'esthétique
- la facilité d'utilisation
*/

require_once('constantes.inc.php');

// test de connexion
try {
    $pdo = new PDO(DSN, UTILISATEUR, MDP);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

$data_1 = [];
$data_2 = [];

try {
    $requeteDates = $pdo->query("SELECT MIN(la_date) AS min_date, MAX(la_date) AS max_date FROM commande");
    $dates = $requeteDates->fetch(PDO::FETCH_ASSOC);
    $min_date = $dates['min_date'] ?? '';
    $max_date = $dates['max_date'] ?? '';
} catch (PDOException $e) {
    echo "<p style='color: red; text-align: center;'>Erreur : " . $e->getMessage() . "</p>";
    $min_date = '';
    $max_date = '';
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['date_debut']) && !empty($_POST['date_fin'])) {
    $date_debut = $_POST['date_debut'];
    $date_fin = $_POST['date_fin'];

    if ($date_debut > $date_fin) {
        echo "<p style='color: red; text-align: center;'>Erreur : La date de début ne peut pas être postérieure à la date de fin.</p>";
        exit(1);
    }
    $requetePreparee = $pdo->prepare("SELECT c.la_date, COUNT(c.id) AS nombre_commandes, SUM(p.quantite) AS nombre_produits FROM porter p JOIN commande c ON p.id_commande = c.id WHERE c.la_date BETWEEN ? AND ? GROUP BY c.la_date ORDER BY c.la_date");
    $requetePreparee->bindParam(1, $date_debut, PDO::PARAM_STR);
    $requetePreparee->bindParam(2, $date_fin, PDO::PARAM_STR);
    $requetePreparee->execute();
} else {
    $requetePreparee = $pdo->prepare("SELECT c.la_date, COUNT(c.id) AS nombre_commandes, SUM(p.quantite) AS nombre_produits FROM porter p JOIN commande c ON p.id_commande = c.id GROUP BY c.la_date ORDER BY c.la_date");
    $requetePreparee->execute();
}

$resultat = $requetePreparee->fetchAll(PDO::FETCH_ASSOC);

foreach ($resultat as $rang) {
    $data_1[] = $rang['la_date'];
    $data_2[] = $rang['nombre_produits'];
    $data_3[] = $rang['nombre_commandes'];
}
$data1 = json_encode($data_1);
$data2 = json_encode($data_2);
$data3 = json_encode($data_3);
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Reims Outillage | Graphiques</title>
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.1.1/chart.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/chartjs-plugin-zoom/2.2.0/chartjs-plugin-zoom.min.js"></script>
</head>

<body style="background: linear-gradient(70deg, rgb(139, 168, 247), pink); background-repeat: no-repeat; height: 910px;">
    <div class="chartes">
        <canvas id="chartId1" aria-label="chart" height="350px" width="700px"></canvas>
        <div id="chartId2" aria-label="chart" height="350px" width="300px"></div>
        <div id="chartId3" aria-label="chart" height="350px" width="600px"></div>
    </div>
    
    <form action="?" method="POST">
        <label for="date_debut">Date début: </label>
        <input type="date" id="date_debut" name="date_debut" min="<?php echo $min_date; ?>"
            max="<?php echo $max_date; ?>" required>
        <br>
        <label for="date_fin">Date fin: </label>
        <input type="date" id="date_fin" name="date_fin" min="<?php echo $min_date; ?>" max="<?php echo $max_date; ?>" required>
        <button type="submit">Envoyer</button>
    </form>

    <form action="index.php" method="GET">
        <button type="submit">Réinitialiser</button>
    </form>

    <style>
        .chartes {
            display: grid;
            grid-template-areas:
                "chart1 chart3"
                "chart2 chart3";
            grid-template-columns: 2fr 1fr;
            grid-template-rows: auto auto;
            gap: 10px;
            align-items: start;
        }

        #chartId1 {
            grid-area: chart1;
        }

        #chartId2 {
            grid-area: chart2;
        }

        #chartId3 {
            grid-area: chart3;
        }

        canvas {
            height: auto;
        }
    </style>

    <script>
        const labels = <?php echo $data1; ?>;
        const dates = <?php echo $data1; ?>;
        const nombre_produits = <?php echo $data2; ?>;
        const nombre_commandes = <?php echo $data3; ?>;
        
        // premier graphe
        var Chart = new Chart(chartId1, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: "Quantité des produits",
                    data: nombre_produits,
                    backgroundColor: 'rgb(245, 198, 215)'
                },
                {
                    label: "Commandes effectuées",
                    data: nombre_commandes,
                    backgroundColor: 'rgb(235, 208, 136)'
                }]
            },
            options: {
                responsive: false,
                plugins: {
                    title: {
                        display: true,
                        text: "Histogramme avec ChartJS",
                        font: {
                            size: 15
                        }
                    },
                    zoom: {
                        zoom: {
                            wheel: {
                                enabled: true
                            },
                            drag: {
                                enabled: true
                            },
                            mode: "x",
                            speed: 100
                        },
                        pan: {
                            enabled: true,
                            mode: "x",
                            speed: 0.5
                        }
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: "Dates"
                        },
                        ticks: {
                            font: {
                                size: 10
                            }
                        }
                    },
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: "Quantité des produits"
                        },
                        ticks: {
                            font: {
                                size: 10
                            }
                        }
                    }
                }
            }
        });
        

        // deuxième graphe
        const optionsApex = {
            chart: {
                type: 'bar',
                height: 350,
                zoom: {
                    enabled: true,
                    type: 'x',  
                    autoScaleYaxis: false,  
                    allowMouseWheelZoom: true,  
                    zoomedArea: {
                        fill: {
                        color: '#90CAF9',
                        opacity: 0.4
                        },
                        stroke: {
                        color: '#0D47A1',
                        opacity: 0.4,
                        width: 1
                        }
                    }
                }
            },
            series: [{
                name: 'Quantité des produits',
                data: nombre_produits
                },
                {
                name: 'Commandes effectuées',
                data: nombre_commandes
                }
            ],
            xaxis: {
                categories: dates,
                tickPlacement: 'on'
            },
            title: {
                text: 'Histogramme avec ApexCharts'
            }
        };
        const chartApex = new ApexCharts(document.querySelector("#chartId2"), optionsApex);
        chartApex.render();
        

        // troisième graphe
        const ProduitsPlotly = {
            x: dates,
            y: nombre_produits,
            name: 'Quantité des produits',
            type: 'bar'
        };

        const CommandesPlotly = {
            x: dates,
            y: nombre_commandes,
            name: 'Commandes effectuées',
            type: 'bar'
        };

        const donneesPlotly = [ProduitsPlotly, CommandesPlotly];

        const stylePlotly = {
            title: 'Histogramme avec Plotly.js',
            paper_bgcolor: 'rgba(0, 0, 0, 0)',
            xaxis: {
                title: 'Dates'
            },
            yaxis: {
                title: 'Valeurs'
            },
            barmode: 'group'
        };
        Plotly.newPlot('chartId3', donneesPlotly, stylePlotly);
    </script>
</body>

</html>