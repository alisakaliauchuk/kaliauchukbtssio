<?php

function connexionBDD() {
    $hote = 'localhost';
    $bdd = 'BDSERIE';
    $user = 'postgres';
    $mdp = 'postgres';

    try {
        $pdo = new PDO("pgsql:host=$hote;dbname=$bdd", $user, $mdp);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        
        return $pdo;
    } catch (PDOException $e) {
        die("Erreur de connexion à la base de données : " . $e->getMessage());
    }
}
