<?php
require_once __DIR__ . '/../M/EscaleModel.php';

class EscaleController {

    private EscaleModel $model;

    public function __construct() {
        $this->model = new EscaleModel();
    }

    /** Fiche escale — activée depuis le bouton "escale" dans la liste navires */
    public function detail(): void {
        $id     = (int) ($_GET['id'] ?? 0);
        $escale = $this->model->getById($id);

        if (!$escale) {
            http_response_code(404);
            $pageTitle = 'Escale introuvable';
            require __DIR__ . '/../V/errors/404.php';
            return;
        }

        $pageTitle = 'Escale n°' . $escale['NumEscale'] . ' — ' . htmlspecialchars($escale['NomNavire']);
        require __DIR__ . '/../V/escale/fiche.php';
    }

    public function index(): void {
        $escales   = $this->model->getAll();
        $pageTitle = 'Toutes les Escales';
        require __DIR__ . '/../V/escale/liste.php';
    }
}
