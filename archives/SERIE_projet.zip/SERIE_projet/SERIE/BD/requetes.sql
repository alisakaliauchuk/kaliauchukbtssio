INSERT INTO
  Utilisateur (identifiant, mot_de_passe)
VALUES
  ('email@exemple.fr', 'hash_genere_par_php');

UPDATE
  Utilisateur
SET
  nom = 'Dupont',
  prenom = 'Jean',
  adresse = '12 rue de la Paix',
  cp = '75001',
  ville = 'Paris',
  tel = '0600000000',
  num_carte = '1234567890123456',
  date_exp = '12/26',
  cvv = '123'
WHERE
  identifiant = 'email@exemple.fr';

SELECT
  mot_de_passe
FROM
  Utilisateur
WHERE
  identifiant = 'email@exemple.fr';

SELECT
  COUNT(*) AS nb
FROM
  Utilisateur
WHERE
  identifiant = 'email@exemple.fr';

SELECT
  s.num_serie,
  s.titre_serieVF,
  s.titre_serieVO,
  s.annee_creation,
  g.lib_genre,
  p.nom_pays,
  per.nom_pers AS createur_nom,
  per.pnom_pers AS createur_prenom
FROM
  Serie s
  JOIN Genre g ON s.num_genre = g.num_genre
  JOIN Pays p ON s.num_pays = p.num_pays
  JOIN Createur c ON s.numero = c.numero
  JOIN Personne per ON c.code_pers = per.code_pers
ORDER BY
  s.titre_serieVF;

SELECT
  s.num_serie,
  s.titre_serieVF,
  s.titre_serieVO,
  s.annee_creation,
  g.lib_genre,
  p.nom_pays,
  per.nom_pers AS createur_nom,
  per.pnom_pers AS createur_prenom,
  STRING_AGG(DISTINCT ch.lib_chaine, ', ') AS chaines
FROM
  Serie s
  JOIN Genre g ON s.num_genre = g.num_genre
  JOIN Pays p ON s.num_pays = p.num_pays
  JOIN Createur c ON s.numero = c.numero
  JOIN Personne per ON c.code_pers = per.code_pers
  LEFT JOIN Diffuser d ON s.num_serie = d.num_serie
  LEFT JOIN Chaine ch ON d.num_chaine = ch.num_chaine
WHERE
  s.num_serie = 1
GROUP BY
  s.num_serie,
  s.titre_serieVF,
  s.titre_serieVO,
  s.annee_creation,
  g.lib_genre,
  p.nom_pays,
  per.nom_pers,
  per.pnom_pers;

SELECT
  num_saison,
  date_debut_tournage,
  date_fin_tournage
FROM
  Saison
WHERE
  num_serie = 1
ORDER BY
  num_saison;

SELECT
  num_epi,
  num_saison,
  num_serie
FROM
  Episode
WHERE
  num_serie = 1
  AND num_saison = 1
ORDER BY
  num_epi;

SELECT
  e.num_epi,
  e.num_saison,
  e.num_serie,
  s.titre_serieVF
FROM
  Episode e
  JOIN Serie s ON e.num_serie = s.num_serie
WHERE
  e.num_serie = 1
  AND e.num_saison = 1
  AND e.num_epi = 1;

INSERT INTO
  Utilisateur (identifiant, mot_de_passe)
VALUES
  (
    'nouveau@seriesite.fr',
    '$2y$10$examplehashgeneratedbbyphp'
  );

SELECT
  identifiant
FROM
  Utilisateur
WHERE
  identifiant = 'nouveau@seriesite.fr';

INSERT INTO
  Utilisateur (identifiant, mot_de_passe)
VALUES
  ('nouveau@seriesite.fr', '$2y$10$autrehashphp');

INSERT INTO
  Personne (code_pers, nom_pers, pnom_pers)
VALUES
  (10, 'Simon', 'David');

INSERT INTO
  Createur (numero, code_pers)
VALUES
  (10, 10);

INSERT INTO
  Serie (
    num_serie,
    titre_serieVF,
    titre_serieVO,
    annee_creation,
    num_pays,
    numero,
    num_genre
  )
VALUES
  (
    6,
    'Nouvelle Serie',
    'New Series',
    2024,
    1,
    10,
    1
  );

INSERT INTO
  Saison (
    num_serie,
    num_saison,
    date_debut_tournage,
    date_fin_tournage
  )
VALUES
  (6, 1, '2024-01-01', '2024-06-30');

INSERT INTO
  Episode (num_epi, num_serie, num_saison)
VALUES
  (1, 6, 1);

SELECT
  s.num_serie,
  s.titre_serieVF,
  g.lib_genre
FROM
  Serie s
  JOIN Genre g ON s.num_genre = g.num_genre
ORDER BY
  s.titre_serieVF;