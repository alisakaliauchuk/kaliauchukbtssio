<?php
require_once __DIR__ . '/Database.php';

class EscaleModel {

    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function getAll(): array {
        $stmt = $this->db->query('SELECT * FROM escale_navire ORDER BY numescale');
        return $stmt->fetchAll();
    }

    public function getByNavire(int $noLloyds): array {
        $stmt = $this->db->prepare(
            'SELECT * FROM escale_navire WHERE nolloyds = :id ORDER BY datearrivee DESC'
        );
        $stmt->execute([':id' => $noLloyds]);
        return $stmt->fetchAll();
    }

    public function getById(int $numEscale): ?array {
        $stmt = $this->db->prepare(
            'SELECT * FROM escale_navire WHERE numescale = :id'
        );
        $stmt->execute([':id' => $numEscale]);
        $row = $stmt->fetch();
        return $row ?: null;
    }
}
