<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>
        <?php echo htmlspecialchars($serie['titre_serievf']); ?>
        – Saison <?php echo intval($numSaison); ?> – Série Site
    </title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header>
    <a href="serieController.php" class="logo">Série Site</a>
    <nav>
        <a href="serieController.php">Catalogue</a>
        <a href="logout.php">Déconnexion</a>
    </nav>
</header>

<div class="contenu">

    <p class="fil-ariane">
        <a href="serieController.php">Catalogue</a> &rsaquo;
        <a href="infoSerieController.php?num_serie=<?php echo intval($serie['num_serie']); ?>">
            <?php echo htmlspecialchars($serie['titre_serievf']); ?>
        </a> &rsaquo;
        Saison <?php echo intval($numSaison); ?>
    </p>

    <h1><?php echo htmlspecialchars($serie['titre_serievf']); ?></h1>

    <div class="selecteur-saison">
        <label for="choix-saison">Saison :</label>
        <select id="choix-saison" onchange="window.location='saisonController.php?num_serie=<?php echo intval($serie['num_serie']); ?>&num_saison=' + this.value">
            <?php foreach ($saisons as $s) : ?>
                <option value="<?php echo intval($s['num_saison']); ?>"
                    <?php if (intval($s['num_saison']) === $numSaison) echo 'selected'; ?>>
                    Saison <?php echo intval($s['num_saison']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <?php if ($saisonCourante !== null) : ?>
    <div class="info-saison">
        <?php if (!empty($saisonCourante['date_debut_tournage'])) : ?>
            Début du tournage : <strong><?php echo htmlspecialchars($saisonCourante['date_debut_tournage']); ?></strong>
            &nbsp;|&nbsp;
        <?php endif; ?>
        <?php if (!empty($saisonCourante['date_fin_tournage'])) : ?>
            Fin du tournage : <strong><?php echo htmlspecialchars($saisonCourante['date_fin_tournage']); ?></strong>
            &nbsp;|&nbsp;
        <?php endif; ?>
        <?php echo count($episodes); ?> épisode(s)
    </div>
    <?php endif; ?>

    <?php if (empty($episodes)) : ?>
        <p class="vide">Aucun épisode disponible pour cette saison.</p>

    <?php else : ?>
        <div class="grille-episodes">
            <?php foreach ($episodes as $ep) : ?>
            <a href="episodeController.php?num_serie=<?php echo intval($ep['num_serie']); ?>&num_saison=<?php echo intval($ep['num_saison']); ?>&num_epi=<?php echo intval($ep['num_epi']); ?>"
               class="carte-episode">
                <div class="vignette">🎬</div>
                <div class="ep-info">
                    Épisode <?php echo intval($ep['num_epi']); ?>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</div>

</body>
</html>
