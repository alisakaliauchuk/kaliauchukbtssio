/c postgres

DROP IF EXISTS DATABASE hotel;

CREATE DATABASE hotel;

/c hotel

CREATE TABLE clients;

