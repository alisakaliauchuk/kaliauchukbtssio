<?php
header("Content-Type: application/json");

// les données pourrait être ici extraite d'une base de données
$numero = $_GET["numero"];
$etat = rand(1, 3);

$reponse = ["numero" => $numero, "etat" => $etat];

// on renvoie la réponse au format JSON
// grâce à la fonction json_encode (voir https://www.php.net/manual/fr/function.json-encode.php)
// exemple de réponse : {"numero": 17, "etat": 2}
echo json_encode($reponse);

?>
