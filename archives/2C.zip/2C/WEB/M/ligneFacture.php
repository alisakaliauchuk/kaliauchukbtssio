<?php
class LigneFacture {
    private string $image;
    private string $reference;
    private string $designation;
    private string $type;
    private int $quantite;
    private float $tarif;
    private float $totalHT;

    public function __construct($image, $ref, $des, $type, $qte, $tarif) {
        $this->image = $image; // ajout image    
        $this->reference = $ref;
        $this->designation = $des;
        $this->type = $type;
        $this->quantite = $qte;
        $this->tarif = $tarif;
        $this->totalHT = $qte * $tarif;
    }

    public function getImage() { return $this->image; } // ajout image
    public function getReference() { return $this->reference; }
    public function getDesignation() { return $this->designation; }
    public function getType() { return $this->type; }
    public function getQuantite() { return $this->quantite; }
    public function getTarif() { return $this->tarif; }
    public function getTotalHT() { return $this->totalHT; }
}
?>
