<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>
        <?php echo htmlspecialchars($serie['titre_serievf']); ?> –
        S<?php echo intval($episode['num_saison']); ?>E<?php echo intval($episode['num_epi']); ?> –
        SérieSite
    </title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header>
    <a href="serieController.php" class="logo">🎬 SérieSite</a>
    <nav>
        <a href="serieController.php">Catalogue</a>
        <a href="logout.php">Déconnexion</a>
    </nav>
</header>

<div class="contenu">

    <p class="fil-ariane">
        <a href="serieController.php">Catalogue</a> &rsaquo;
        <a href="infoSerieController.php?num_serie=<?php echo intval($episode['num_serie']); ?>">
            <?php echo htmlspecialchars($serie['titre_serievf']); ?>
        </a> &rsaquo;
        <a href="saisonController.php?num_serie=<?php echo intval($episode['num_serie']); ?>&num_saison=<?php echo intval($episode['num_saison']); ?>">
            Saison <?php echo intval($episode['num_saison']); ?>
        </a> &rsaquo;
        Épisode <?php echo intval($episode['num_epi']); ?>
    </p>

    <h1>
        <?php echo htmlspecialchars($serie['titre_serievf']); ?> —
        <?php if (!empty($episode['titre_vf'])) : ?>
            <?php echo htmlspecialchars($episode['titre_vf']); ?>
        <?php else : ?>
            Saison <?php echo intval($episode['num_saison']); ?>,
            Épisode <?php echo intval($episode['num_epi']); ?>
        <?php endif; ?>
    </h1>

    <!-- Zone lecteur vidéo : affiche "Vidéo lancée" -->
    <div class="lecteur-video">
        <div class="icone-play">▶</div>
        <p>Vidéo</p>
        <p class="sous-titre">
            <?php echo htmlspecialchars($serie['titre_serievf']); ?> —
            Saison <?php echo intval($episode['num_saison']); ?>,
            Épisode <?php echo intval($episode['num_epi']); ?>
            <?php if (!empty($episode['titre_vo'])) : ?>
                — "<?php echo htmlspecialchars($episode['titre_vo']); ?>"
            <?php endif; ?>
        </p>
    </div>

    <!-- Résumé de l'épisode si disponible -->
    <?php if (!empty($episode['resume_epi'])) : ?>
    <div class="bloc-resume">
        <strong>Résumé :</strong>
        <?php echo htmlspecialchars($episode['resume_epi']); ?>
    </div>
    <?php endif; ?>

    <br>
    <a href="saisonController.php?num_serie=<?php echo intval($episode['num_serie']); ?>&num_saison=<?php echo intval($episode['num_saison']); ?>"
       class="btn btn-gris">← Retour aux épisodes</a>

</div>

</body>
</html>
