<?php

session_start();
require_once '../model/utilisateurModel.php';

if (isset($_SESSION['utilisateur'])) {
    header('Location: serieController.php');
    exit;
}

$action = $_POST['action'] ?? $_GET['action'] ?? 'login';
$erreur = '';


if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifiant = trim($_POST['identifiant'] ?? '');
    $motDePasse = $_POST['mot_de_passe'] ?? '';

    if ($identifiant === '' || $motDePasse === '') {
        $erreur = "Veuillez remplir tous les champs.";
    } elseif (!verifierConnexion($identifiant, $motDePasse)) {
        $erreur = "Vous n'êtes pas inscrit ou mot de passe incorrect. Retour à la page d'authentification.";
    } else {
        $_SESSION['utilisateur'] = $identifiant;
        header('Location: serieController.php');
        exit;
    }
}


if ($action === 'inscription_etape1' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifiant = trim($_POST['identifiant'] ?? '');
    $motDePasse = $_POST['mot_de_passe'] ?? '';
    $confirmation = $_POST['confirmation'] ?? '';

    if ($identifiant === '' || $motDePasse === '') {
        $erreur = "Veuillez remplir tous les champs.";
        $action = 'inscription';
    } elseif ($motDePasse !== $confirmation) {
        $erreur = "Les mots de passe ne correspondent pas.";
        $action = 'inscription';
    } elseif (utilisateurExiste($identifiant)) {
        $erreur = "Cet identifiant est déjà utilisé. Retour à la page d'authentification.";
        $action = 'inscription';
    } elseif (!inscrireEtape1($identifiant, $motDePasse)) {
        $erreur = "Erreur lors de l'inscription. Veuillez réessayer.";
        $action = 'inscription';
    } else {
        $_SESSION['inscription_identifiant'] = $identifiant;
        $action = 'infos_personnelles';
    }
}


if ($action === 'inscription_etape2' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['inscription_identifiant'])) {
        $action = 'login';
    } else {
        $identifiant = $_SESSION['inscription_identifiant'];
        $nom = trim($_POST['nom'] ?? '');
        $prenom = trim($_POST['prenom'] ?? '');
        $adresse = trim($_POST['adresse'] ?? '');
        $cp = trim($_POST['cp'] ?? '');
        $ville = trim($_POST['ville'] ?? '');
        $tel = trim($_POST['tel'] ?? '');
        $numCarte = trim($_POST['num_carte'] ?? '');
        $dateExp = trim($_POST['date_exp'] ?? '');
        $cvv = trim($_POST['cvv'] ?? '');

        if ($nom === '' || $prenom === '' || $adresse === '' || $cp === '' || $ville === '') {
            $erreur = "Veuillez remplir les champs obligatoires (nom, prénom, adresse, CP, ville).";
            $action = 'infos_personnelles';
        } elseif (!inscrireEtape2($identifiant, $nom, $prenom, $adresse, $cp, $ville, $tel, $numCarte, $dateExp, $cvv)) {
            $erreur = "Erreur lors de l'enregistrement. Veuillez réessayer.";
            $action = 'infos_personnelles';
        } else {
            unset($_SESSION['inscription_identifiant']);
            $_SESSION['utilisateur'] = $identifiant;
            header('Location: serieController.php');
            exit;
        }
    }
}

switch ($action) {
    case 'inscription':
        require '../vue/inscription.php';
        break;
    case 'infos_personnelles':
        require '../vue/infoPersonnelles.php';
        break;
    default:
        require '../vue/login.php';
}
