<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>
        <?php echo htmlspecialchars($serie['titre_serievf']); ?>
        – S<?php echo intval($episode['num_saison']); ?>E<?php echo intval($episode['num_epi']); ?>
        – Série Site
    </title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header>
    <a href="serieController.php" class="logo">Série Site</a>
    <nav>
        <a href="serieController.php">Catalogue</a>
        <a href="logout.php">Déconnexion</a>
    </nav>
</header>

<div class="contenu">

    <p class="fil-ariane">
        <a href="serieController.php">Catalogue</a> &rsaquo;
        <a href="infoSerieController.php?num_serie=<?php echo intval($episode['num_serie']); ?>">
            <?php echo htmlspecialchars($serie['titre_serievf']); ?>
        </a> &rsaquo;
        <a href="saisonController.php?num_serie=<?php echo intval($episode['num_serie']); ?>&num_saison=<?php echo intval($episode['num_saison']); ?>">
            Saison <?php echo intval($episode['num_saison']); ?>
        </a> &rsaquo;
        Épisode <?php echo intval($episode['num_epi']); ?>
    </p>

    <h1>
        <?php echo htmlspecialchars($serie['titre_serievf']); ?> –
        Saison <?php echo intval($episode['num_saison']); ?>,
        Épisode <?php echo intval($episode['num_epi']); ?>
    </h1>

    <div class="lecteur-video">
        <?php
        $cheminVideo = '../assets/videos/'
            . intval($episode['num_serie'])  . '_'
            . intval($episode['num_saison']) . '_'
            . intval($episode['num_epi'])    . '.mp4';

        $cheminPhysique = __DIR__ . '/../assets/videos/'
            . intval($episode['num_serie'])  . '_'
            . intval($episode['num_saison']) . '_'
            . intval($episode['num_epi'])    . '.mp4';
        ?>

        <?php if (file_exists($cheminPhysique)) : ?>
            <video controls autoplay>
                <source src="<?php echo $cheminVideo; ?>" type="video/mp4">
                Votre navigateur ne supporte pas la lecture vidéo.
            </video>
        <?php else : ?>
            <div class="placeholder-video">
                <p style="font-size: 40px;">🎬</p>
                <p>Vidéo non disponible</p>
                <p style="font-size:13px; margin-top:8px; color:#444;">
                    Fichier attendu : assets/videos/<?php echo intval($episode['num_serie']); ?>_<?php echo intval($episode['num_saison']); ?>_<?php echo intval($episode['num_epi']); ?>.mp4
                </p>
            </div>
        <?php endif; ?>
    </div>
    <a href="saisonController.php?num_serie=<?php echo intval($episode['num_serie']); ?>&num_saison=<?php echo intval($episode['num_saison']); ?>"
       class="btn btn-gris">← Retour aux épisodes</a>
</div>

</body>
</html>
