#include <iostream>
#include "personne.h"

using namespace std;

int N = 0;

int main()
{
    personne p1("Alisa");
    personne p2("Julia");

    // tableau stat
    personne tabS[2] = {p1, p2};

    cout << "\nContenu du tableau tabS" << endl;
    for (int i = 0; i < 2; i++)
    {
        tabS[i].afficher();
    }

    // tableau dynm
    do {
        cout << "\nEntrez la taille N du tab dnamique (> 2): ";
        cin >> N;
        if (N <= 2)
            cout << "Erreur: N doit être > 2." << endl;
    } while (N <= 2);

    personne* tabD = new personne[N];

    // initialisation des 2 premieres cases
    int tailleActuelle = 0;
    tabD[tailleActuelle++] = p1;
    tabD[tailleActuelle++] = p2;

    cout << "\nContenu initial de tabD" << endl;
    affichePersonne(tabD, tailleActuelle);

    // test
    cout << "\nTest controlPersonne" << endl;
    controlPersonne(tabD, tailleActuelle, "Louis", N); //si nouvelle personne, il s'ajoute
    controlPersonne(tabD, tailleActuelle, "Alisa", N); //si le même, erreur

    affichePersonne(tabD, tailleActuelle);

    saisiePersonne(tabD, tailleActuelle, N);

    cout << "\nRésultat final" << endl;
    affichePersonne(tabD, tailleActuelle);

    return 0;
}
