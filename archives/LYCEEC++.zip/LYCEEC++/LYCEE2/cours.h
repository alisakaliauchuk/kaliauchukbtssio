#ifndef COURS_H
#define COURS_H
#include <string>

using namespace std;

class enseignant;

class cours
{
public:
    string intitule;
    enseignant* enseignantDuCours;

    cours(string intitule);
};
#endif
