<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($serie['titre_serievf']); ?> – SérieSite</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header>
    <a href="serieController.php" class="logo">🎬 SérieSite</a>
    <nav>
        <a href="serieController.php">Catalogue</a>
        <a href="logout.php">Déconnexion</a>
    </nav>
</header>

<div class="contenu">

    <p class="fil-ariane">
        <a href="serieController.php">Catalogue</a> &rsaquo;
        <?php echo htmlspecialchars($serie['titre_serievf']); ?>
    </p>

    <div class="bloc-info-serie">

        <!-- Icône TV en haut à droite -->
        <div class="icone-tv">
            <a href="saisonController.php?num_serie=<?php echo intval($serie['num_serie']); ?>&num_saison=1"
               title="Voir les saisons">📺</a>
        </div>

        <!-- Titre centré en bleu -->
        <div class="titre-serie-page">
            <?php echo htmlspecialchars($serie['titre_serievf']); ?>
        </div>

        <!-- Layout : image gauche + tableau droite -->
        <div class="layout-info">

            <img src="../assets/images/<?php echo intval($serie['num_serie']); ?>.jpg"
                 onerror="this.src='../assets/images/default.jpg'"
                 alt="<?php echo htmlspecialchars($serie['titre_serievf']); ?>">

            <table class="table-info">
                <tr>
                    <td>Créateur :</td>
                    <td><?php echo htmlspecialchars($serie['createur_prenom'] . ' ' . $serie['createur_nom']); ?></td>
                </tr>
                <tr>
                    <td>Année de création :</td>
                    <td><?php echo htmlspecialchars($serie['annee_creation'] ?? '—'); ?></td>
                </tr>
                <tr>
                    <td>Nombre de saisons (actuellement) :</td>
                    <td><?php echo intval($serie['nb_saisons']); ?></td>
                </tr>
                <tr>
                    <td>Genre :</td>
                    <td><?php echo htmlspecialchars($serie['lib_genre']); ?></td>
                </tr>
                <tr>
                    <td>Titre FR :</td>
                    <td><?php echo htmlspecialchars($serie['titre_serievf']); ?></td>
                </tr>
                <tr>
                    <td>Titre VO :</td>
                    <td><?php echo htmlspecialchars($serie['titre_serievo']); ?></td>
                </tr>
                <tr>
                    <td>Pays d'origine :</td>
                    <td><?php echo htmlspecialchars($serie['nom_pays']); ?></td>
                </tr>
                <tr>
                    <td>Durée moyenne d'un épisode :</td>
                    <td><?php echo intval($serie['duree_episode']); ?> min</td>
                </tr>
                <?php if (!empty($serie['chaines_france'])) : ?>
                <tr>
                    <td>Diffusion en France :</td>
                    <td><?php echo htmlspecialchars($serie['chaines_france']); ?></td>
                </tr>
                <?php endif; ?>
                <?php if (!empty($serie['chaines_us'])) : ?>
                <tr>
                    <td>Diffusion aux États-Unis :</td>
                    <td><?php echo htmlspecialchars($serie['chaines_us']); ?></td>
                </tr>
                <?php endif; ?>
                <?php if (!empty($serie['musique'])) : ?>
                <tr>
                    <td>Musique du générique :</td>
                    <td><?php echo htmlspecialchars($serie['musique']); ?></td>
                </tr>
                <?php endif; ?>
            </table>
        </div>

        <!-- Résumé -->
        <?php if (!empty($serie['resume'])) : ?>
        <div class="bloc-resume">
            <strong>Résumé :</strong>
            <?php echo htmlspecialchars($serie['resume']); ?>
        </div>
        <?php endif; ?>

    </div>

    <a href="serieController.php" class="btn btn-gris">← Retour au catalogue</a>

</div>

</body>
</html>
