<?php
include_once("../M/fonctions.php");
$listeFactures = getAllFactures();
include_once("../V/vue_factures.php");
?>
