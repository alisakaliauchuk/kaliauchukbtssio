<?php
define('HOST', '127.0.0.1');
define('DBNAME', 'cartouche');
define('USER', 'postgres');
define('PASS', 'postgres');
?>