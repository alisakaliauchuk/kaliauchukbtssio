<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Catalogue des séries – SérieSite</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header>
    <a href="serieController.php" class="logo">🎬 SérieSite</a>
    <nav>
        <a href="serieController.php">Catalogue</a>
        <a href="logout.php">Déconnexion</a>
    </nav>
</header>

<div class="contenu">
    <h1>Liste des séries</h1>

    <?php if (empty($series)) : ?>
        <p class="vide">Aucune série disponible pour le moment.</p>
    <?php else : ?>
        <table>
            <thead>
                <tr>
                    <th>Affiche</th>
                    <th>Titre VF</th>
                    <th>Titre VO</th>
                    <th>Genre</th>
                    <th>Pays</th>
                    <th>Année</th>
                    <th>Créateur</th>
                    <th>Saisons</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($series as $serie) : ?>
                <tr>
                    <td>
                        <a href="infoSerieController.php?num_serie=<?php echo intval($serie['num_serie']); ?>">
                            <img src="../assets/images/<?php echo intval($serie['num_serie']); ?>.jpg"
                                 onerror="this.src='../assets/images/default.jpg'"
                                 alt="<?php echo htmlspecialchars($serie['titre_serievf']); ?>"
                                 class="img-serie">
                        </a>
                    </td>
                    <td><?php echo htmlspecialchars($serie['titre_serievf']); ?></td>
                    <td><?php echo htmlspecialchars($serie['titre_serievo']); ?></td>
                    <td><?php echo htmlspecialchars($serie['lib_genre']); ?></td>
                    <td><?php echo htmlspecialchars($serie['nom_pays']); ?></td>
                    <td><?php echo htmlspecialchars($serie['annee_creation'] ?? '—'); ?></td>
                    <td><?php echo htmlspecialchars($serie['createur_prenom'] . ' ' . $serie['createur_nom']); ?></td>
                    <td>
                        <a href="saisonController.php?num_serie=<?php echo intval($serie['num_serie']); ?>&num_saison=1"
                           class="lien-tv" title="Voir les saisons">📺</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

</body>
</html>
