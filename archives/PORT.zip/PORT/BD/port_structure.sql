CREATE TABLE PAYS (
    CodePays CHAR(2) PRIMARY KEY,
    NomPays VARCHAR(50) NOT NULL
);
CREATE TABLE PORT (
    NumPort INT PRIMARY KEY,
    CodePays CHAR(2) NOT NULL,
    NomPort VARCHAR(50) NOT NULL,
    FOREIGN KEY (CodePays) REFERENCES PAYS(CodePays)
);
CREATE TABLE QUAI (
    CodeQuai INT PRIMARY KEY,
    NomQuai VARCHAR(50) NOT NULL,
    TirantDEauMax DECIMAL(5,2) CHECK (TirantDEauMax > 0)
);
CREATE TABLE POSTE (
    NumPoste INT PRIMARY KEY,
    LongueurPoste DECIMAL(6,2) CHECK (LongueurPoste > 0),
    CodeQuai INT NOT NULL,
    FOREIGN KEY (CodeQuai) REFERENCES QUAI(CodeQuai)
);

CREATE TABLE TYPE_NAVIRE (
    CodeTypeNavire INT PRIMARY KEY,
    NomArmateur VARCHAR(100),
    AdresseArmateur VARCHAR(150)
);

CREATE TABLE ARMATEUR (
    CodeArmateur INT PRIMARY KEY,
    LibelleTypeNavire VARCHAR(100)
);

CREATE TABLE NAVIRE (
    NoLloyds INT PRIMARY KEY,
    NomNavire VARCHAR(100) NOT NULL,
    Largeur DECIMAL(5,2),
    Longueur DECIMAL(6,2),
    Capacite INT,
    TirantDEau DECIMAL(5,2),
    Propulse BOOLEAN,
    Interdit BOOLEAN,
    NumPort INT,
    CodePays CHAR(2),
    CodeTypeNavire INT,
    CodeArmateur INT,
    FOREIGN KEY (NumPort) REFERENCES PORT(NumPort),
    FOREIGN KEY (CodePays) REFERENCES PAYS(CodePays),
    FOREIGN KEY (CodeTypeNavire) REFERENCES TYPE_NAVIRE(CodeTypeNavire),
    FOREIGN KEY (CodeArmateur) REFERENCES ARMATEUR(CodeArmateur)
);

CREATE TABLE EMPLOYE (
    CodeEmploye INT PRIMARY KEY,
    NomEmploye VARCHAR(100)
);

CREATE TABLE DOCKER (
    CodeEmploye INT PRIMARY KEY,
    FOREIGN KEY (CodeEmploye) REFERENCES EMPLOYE(CodeEmploye)
);

CREATE TABLE PILOTE (
    CodeEmploye INT PRIMARY KEY,
    FOREIGN KEY (CodeEmploye) REFERENCES EMPLOYE(CodeEmploye)
);

CREATE TABLE TYPE_FRET (
    CodeTypeFret INT PRIMARY KEY,
    PrixRevient DECIMAL(10,2),
    MatiereDangereuse BOOLEAN
);

CREATE TABLE ESCALE (
    NumEscale INT PRIMARY KEY,
    DateArrivee DATE,
    DateDepart DATE,
    Provenance VARCHAR(100),
    Destination VARCHAR(100),
    ImportExport VARCHAR(10),
    Tonnage DECIMAL(10,2),
    QteFret INT,
    EscaleConfirmee BOOLEAN,
    NoLloyds INT,
    CodeEmployeDocker INT,
    CodePiloteEntree INT,
    CodePiloteSortie INT,
    CodeTypeFret INT,
    NumPoste INT,
    FOREIGN KEY (NoLloyds) REFERENCES NAVIRE(NoLloyds),
    FOREIGN KEY (CodeEmployeDocker) REFERENCES DOCKER(CodeEmploye),
    FOREIGN KEY (CodePiloteEntree) REFERENCES PILOTE(CodeEmploye),
    FOREIGN KEY (CodePiloteSortie) REFERENCES PILOTE(CodeEmploye),
    FOREIGN KEY (CodeTypeFret) REFERENCES TYPE_FRET(CodeTypeFret),
    FOREIGN KEY (NumPoste) REFERENCES POSTE(NumPoste)
);
