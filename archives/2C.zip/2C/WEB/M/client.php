<?php
class Client {
    private int $id;
    private string $nom;
    private string $adresse;
    private string $cp;
    private string $ville;
    private string $tel;

    public function __construct(int $id, string $nom, string $adresse = "", string $cp = "", string $ville = "", string $tel = "") {
        $this->id = $id;
        $this->nom = $nom;
        $this->adresse = $adresse;
        $this->cp = $cp;
        $this->ville = $ville;
        $this->tel = $tel;
    }

    public function getId()      { return $this->id; }
    public function getNom()     { return $this->nom; }
    public function getAdresse() { return $this->adresse; }
    public function getCp()      { return $this->cp; }
    public function getVille()   { return $this->ville; }
    public function getTel()     { return $this->tel; }
}
?>
