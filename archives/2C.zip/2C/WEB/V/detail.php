<?php
include_once("../M/fonctions.php");

ini_set("display_errors", 1);
error_reporting(E_ALL);

if (!isset($_GET['id'])) {
    die("Erreur : aucune facture demandée.");
}

$id = intval($_GET['id']);

$facture = getFactureById($id);
$lignes  = getDetailFacture($id);
$avoirs  = getAvoirsFacture($id);

$totalHT = 0;
foreach($lignes as $l){
    $totalHT += $l->getTotalHT();
}

$totalAvoir = 0;
foreach($avoirs as $a){
    $totalAvoir += $a->getMontant();
}

$totalHT -= $totalAvoir;

$tva = $totalHT * Facture::$TVA;
$totalTTC = $totalHT + $tva;
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Détail facture</title>
</head>

<body>
<center>
    <h1>CHAMPAGNE CARTOUCHE</h1>
    <p>10 rue de l’encre<br>51100 REIMS<br>03.26.12.34.56</p>

    <h2>CLIENT</h2>
    <p>
        <strong><?= $facture->getClient()->getNom() ?></strong><br>
        <?= $facture->getClient()->getAdresse() ?><br>
        <?= $facture->getClient()->getCp() . " " . $facture->getClient()->getVille() ?><br>
        <?= $facture->getClient()->getTel() ?>
    </p>

    <h2>FACTURE n° <?= $facture->getId() ?></h2>
    <p>en date du <?= $facture->getDate() ?></p>

    <table border="1">
        <tr>
            <th>Image</th>
            <th>Référence</th>
            <th>Désignation</th>
            <th>Type</th>
            <th>Quantité</th>
            <th>Prix HT</th>
            <th>Montant HT</th>
        </tr>

        <?php foreach($lignes as $l) { ?>
        <tr>
            <td><img src="../images/<?= $l->getImage() ?>" alt="<?= $l->getDesignation() ?>" width="80" height="80"></td> <!-- ajout d'image qui s'affiche sur site (tous même taille) -->
            <td><?= $l->getReference() ?></td>
            <td><?= $l->getDesignation() ?></td>
            <td><?= $l->getType() ?></td>
            <td><?= $l->getQuantite() ?></td>
            <td><?= $l->getTarif() ?> €</td>
            <td><?= $l->getTotalHT() ?> €</td>
        </tr>
        <?php } ?>
    </table>

    <p>Avoir appliqué : <?= $totalAvoir ?> €</p>
    <p>Total HT : <?= $totalHT ?> €</p>
    <p>TVA (20%) : <?= $tva ?> €</p>
    <p>Total TTC : <?= $totalTTC ?> €</p>

    <br>
    <a href="../C/index.php">Retour</a>

</center>
</body>
</html>
