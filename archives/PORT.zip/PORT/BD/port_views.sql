CREATE OR REPLACE VIEW liste_navire 
AS
SELECT
    n.NoLloyds,
    n.NomNavire,
    n.CodeTypeNavire AS TypeNavire,
    pays.CodePays AS Pavillon,
    p.NumPort AS Port,
    n.Largeur,
    n.Longueur,
    n.TirantDEau,
    n.Capacite,
    tn.NomArmateur,
    n.Propulse
FROM NAVIRE n
JOIN TYPE_NAVIRE tn 
      ON n.CodeTypeNavire = tn.CodeTypeNavire
JOIN ARMATEUR a
      ON n.CodeArmateur = a.CodeArmateur
JOIN PORT p
      ON n.NumPort = p.NumPort
     AND n.CodePays = p.CodePays
JOIN PAYS pays
      ON p.CodePays = pays.CodePays
ORDER BY n.NoLloyds;


CREATE OR REPLACE VIEW Escale_Navire AS
SELECT
    e.NumEscale,
    n.NoLloyds,
    n.NomNavire,
    n.Longueur,
    n.Largeur,
    n.TirantDEau,
    n.Propulse AS Propulseur,
    p_ent.NomEmploye  AS PiloteEntree,
    p_sort.NomEmploye AS PiloteSortie,
    e.DateArrivee,
    e.DateDepart,
    e.Provenance,
    e.Destination,
    e.ImportExport,
    e.Tonnage,
    e.QteFret,
    e.EscaleConfirmee,
    q.CodeQuai,
    q.NomQuai,
    pt.NumPoste,
    pt.LongueurPoste,
    tf.CodeTypeFret,
    tf.PrixRevient,
    tf.MatiereDangereuse
FROM ESCALE e
JOIN NAVIRE n           ON e.NoLloyds          = n.NoLloyds
JOIN EMPLOYE p_ent      ON e.CodePiloteEntree   = p_ent.CodeEmploye
JOIN EMPLOYE p_sort     ON e.CodePiloteSortie   = p_sort.CodeEmploye
JOIN POSTE pt           ON e.NumPoste           = pt.NumPoste
JOIN QUAI q             ON pt.CodeQuai          = q.CodeQuai
JOIN TYPE_FRET tf       ON e.CodeTypeFret       = tf.CodeTypeFret
ORDER BY e.NumEscale;


CREATE OR REPLACE VIEW Liste_quais_typeFret AS
SELECT
    q.CodeQuai  AS NumQuai,
    q.NomQuai,
    tf.CodeTypeFret,
    tf.PrixRevient,
    tf.MatiereDangereuse
FROM QUAI q
JOIN POSTE pt    ON q.CodeQuai      = pt.CodeQuai
JOIN ESCALE e    ON pt.NumPoste     = e.NumPoste
JOIN TYPE_FRET tf ON e.CodeTypeFret = tf.CodeTypeFret
ORDER BY q.CodeQuai;


CREATE OR REPLACE VIEW Liste_quais_postes AS
SELECT
    q.CodeQuai AS NumQuai,
    q.NomQuai,
    q.TirantDEauMax,
    pt.NumPoste,
    pt.LongueurPoste
FROM QUAI q
JOIN POSTE pt ON q.CodeQuai = pt.CodeQuai
ORDER BY q.CodeQuai, pt.NumPoste;