#include <QtTest>
#include "../LYCEE/personne.h"
#include "../LYCEE2/enseignant.h"
#include "../LYCEE2/etudiant.h"
#include "../LYCEE2/ville.h"


// add necessary includes here

class TestPersonne : public QObject
{
    Q_OBJECT

public:
    TestPersonne();
    ~TestPersonne();

private slots:
    void test_case1();
    void test_case2();
    void test_case3();
    void test_case4();
    void test_case5();
    void test_case6();
    void test_case7();
    void test_case_nom();
    void test_case_prenom();
    void test_case_ville();
    void test_case_numcarte();
    void test_case_matiere();
};

TestPersonne::TestPersonne()
{

}

TestPersonne::~TestPersonne()
{

}

void TestPersonne::test_case1()
{
    personne p("estelle", 'F');
    QVERIFY(p.nom == "estelle");
}

void TestPersonne::test_case2()
{
    personne p("estelle", 'F');
    QVERIFY(p.verifSexe('F'));
}

void TestPersonne::test_case3()
{
    personne p("estelle");
    QVERIFY(p.verifSexe('F') == false);
    QVERIFY(p.verifSexe('H') == false);
}

void TestPersonne::test_case4()
{
    personne p("estelle", 'H');
    QVERIFY(p.verifSexe('H'));
}

void TestPersonne::test_case5()
{
    personne p("estelle", 'f');
    QVERIFY(p.verifSexe('F') == false);
    QVERIFY(p.verifSexe('H') == false);
}

void TestPersonne::test_case6()
{
    personne p("estelle", 'h');
    QVERIFY(p.verifSexe('F') == false);
    QVERIFY(p.verifSexe('H') == false);
}

void TestPersonne::test_case7()
{
    personne p("estelle", 'X');
    QVERIFY(p.verifSexe('F') == false);
    QVERIFY(p.verifSexe('H') == false);
}

void TestPersonne::test_case_nom()
{
    personne p("Dupont", "Alice", 'F');
    QVERIFY(p.nom == "Dupont");
}

void TestPersonne::test_case_prenom()
{
    personne p("Dupont", "Alice", 'F');
    QVERIFY(p.prenom == "Alice");
}

void TestPersonne::test_case_ville()
{
    ville* v = new ville("Reims", "51100");
    etudiant e("Dupont", "001");
    e.maVille = v;
    QVERIFY(e.maVille != nullptr);
    QVERIFY(e.maVille->nom == "Reims");
    delete v;
}

void TestPersonne::test_case_numcarte()
{
    etudiant e("Dupont", "001");
    QVERIFY(e.numcarte == "001");
}

void TestPersonne::test_case_matiere()
{
    enseignant ens("Gougelet", "SLAM", 'F', 2500.0, nullptr);
    QVERIFY(ens.matiere == "SLAM");
}

QTEST_APPLESS_MAIN(TestPersonne)

#include "tst_testpersonne.moc"
