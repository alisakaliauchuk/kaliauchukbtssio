<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des factures</title>
</head>
<center>
<body>

    <h1>CHAMPAGNE CARTOUCHE</h1>
    <p>10 rue de l’encre, 51100 REIMS<br>03.26.12.34.56</p>
    
    <h1>Liste des factures</h1>

    <table border="1">
        <tr>
            <th>N° Facture</th>
            <th>Date</th>
            <th>Nom du client</th>
            <th>Détail</th>
        </tr>

    <?php foreach($listeFactures as $f) { ?>
        <tr>
            <td><?= $f->getId() ?></td>
            <td><?= $f->getDate() ?></td>
            <td><?= $f->getClient()->getNom() ?></td>
            <td><a href="../V/detail.php?id=<?= $f->getId() ?>">Détail</a></td>
        </tr>
    <?php } ?>
    
    </table>
</body>
</center>
</html>
