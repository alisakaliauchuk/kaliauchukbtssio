CREATE TABLE Utilisateur (
    id_utilisateur SERIAL PRIMARY KEY,
    identifiant VARCHAR(100) UNIQUE NOT NULL,
    mot_de_passe VARCHAR(255) NOT NULL,
    prenom VARCHAR(50),
    nom VARCHAR(50),
    adresse VARCHAR(255),
    cp VARCHAR(10),
    ville VARCHAR(100),
    tel VARCHAR(20),
    num_carte VARCHAR(50),
    date_exp VARCHAR(10),
    cvv VARCHAR(4)
);


CREATE TABLE Personne (
    code_pers INT PRIMARY KEY,
    nom_pers VARCHAR(50),
    pnom_pers VARCHAR(50)
);

CREATE TABLE Producteur (
    numero INT PRIMARY KEY,
    code_pers INT,
    FOREIGN KEY(code_pers) REFERENCES Personne(code_pers)
);

CREATE TABLE Createur (
    numero INT PRIMARY KEY,
    code_pers INT,
    FOREIGN KEY(code_pers) REFERENCES Personne(code_pers)
);

CREATE TABLE Scenariste (
    numero INT PRIMARY KEY,
    code_pers INT,
    FOREIGN KEY(code_pers) REFERENCES Personne(code_pers)
);

CREATE TABLE Realisateur (
    numero INT PRIMARY KEY,
    code_pers INT,
    FOREIGN KEY(code_pers) REFERENCES Personne(code_pers)
);

CREATE TABLE Acteur (
    numero INT PRIMARY KEY,
    code_pers INT,
    FOREIGN KEY(code_pers) REFERENCES Personne(code_pers)
);

CREATE TABLE Doubleur (
    numero INT PRIMARY KEY,
    code_pers INT,
    FOREIGN KEY(code_pers) REFERENCES Personne(code_pers)
);

CREATE TABLE Genre (
    num_genre INT PRIMARY KEY,
    lib_genre VARCHAR(50)
);

CREATE TABLE Chaine (
    num_chaine INT PRIMARY KEY,
    lib_chaine VARCHAR(50),
    num_pays INT
);

CREATE TABLE Pays (
    num_pays INT PRIMARY KEY,
    nom_pays VARCHAR(50)
);

CREATE TABLE Serie (
    num_serie INT PRIMARY KEY,
    titre_serieVF VARCHAR(100),
    titre_serieVO VARCHAR(100),
    num_pays INT,
    numero INT,
    num_genre INT,

    annee_creation INT CHECK (annee_creation > 0 AND annee_creation < YEAR(CURDATE())),

    FOREIGN KEY(num_pays) REFERENCES Pays(num_pays),
    FOREIGN KEY(numero) REFERENCES Createur(numero),
    FOREIGN KEY(num_genre) REFERENCES Genre(num_genre)
);

CREATE TABLE Saison (
    num_serie INT,
    num_saison INT CHECK (num_saison > 0),
    date_debut_tournage DATE,
    date_fin_tournage DATE,
    PRIMARY KEY(num_serie,num_saison),
    FOREIGN KEY(num_serie) REFERENCES Serie(num_serie),

    CHECK (date_debut_tournage < date_fin_tournage)
);

CREATE TABLE Episode (
    num_epi INT CHECK (num_epi > 0),
    num_serie INT,
    num_saison INT,
    PRIMARY KEY(num_epi,num_serie,num_saison),
    FOREIGN KEY(num_serie,num_saison) REFERENCES Saison(num_serie,num_saison)
);

CREATE TABLE Personnage (
    desc_perso VARCHAR(100),
    code_pers INT PRIMARY KEY,
    FOREIGN KEY(code_pers) REFERENCES Personne(code_pers)
);

CREATE TABLE Position (
    num_pos INT PRIMARY KEY,
    lib_pos VARCHAR(50)
);

CREATE TABLE Interprete (
    code_pers INT,
    num_serie INT,
    num_saison INT,
    num_epi INT,
    guest_star VARCHAR(20),
    numero INT,
    numero_1 INT,
    PRIMARY KEY(code_pers,num_serie,num_saison,num_epi),
    FOREIGN KEY(code_pers) REFERENCES Personnage(code_pers),
    FOREIGN KEY(num_serie,num_saison,num_epi) REFERENCES Episode(num_serie,num_saison,num_epi),
    FOREIGN KEY(numero) REFERENCES Doubleur(numero),
    FOREIGN KEY(numero_1) REFERENCES Acteur(numero)
);

CREATE TABLE Attacher (
    code_pers INT,
    num_pos INT,
    PRIMARY KEY(code_pers, num_pos),
    FOREIGN KEY (code_pers) REFERENCES Personnage(code_pers),
    FOREIGN KEY (num_pos) REFERENCES Position(num_pos)
);

CREATE TABLE Diffuser (
    num_serie INT,
    num_chaine INT,
    PRIMARY KEY(num_serie, num_chaine),
    FOREIGN KEY (num_serie) REFERENCES Serie(num_serie),
    FOREIGN KEY (num_chaine) REFERENCES Chaine(num_chaine)
);

CREATE TABLE Produire (
    numero INT,
    num_serie INT,
    PRIMARY KEY(numero, num_serie),
    FOREIGN KEY (numero) REFERENCES Producteur(numero),
    FOREIGN KEY (num_serie) REFERENCES Serie(num_serie)
);

CREATE TABLE Scenariser (
    numero INT,
    num_serie INT,
    num_saison INT,
    num_epi INT,
    PRIMARY KEY(numero, num_serie, num_saison, num_epi),
    FOREIGN KEY (numero) REFERENCES Scenariste(numero),
    FOREIGN KEY (num_serie, num_saison, num_epi)
        REFERENCES Episode(num_serie, num_saison, num_epi)
);

CREATE TABLE Realiser (
    numero INT,
    num_serie INT,
    num_saison INT,
    num_epi INT,
    PRIMARY KEY(numero, num_serie, num_saison, num_epi),
    FOREIGN KEY (numero) REFERENCES Realisateur(numero),
    FOREIGN KEY (num_serie, num_saison, num_epi)
        REFERENCES Episode(num_serie, num_saison, num_epi)
);