<?php
session_start();
if (!isset($_SESSION['utilisateur'])) { header('Location: index.php'); exit; }

require_once '../model/serieModel.php';
$series = getToutesLesSeries();
require '../vue/listeSeries.php';
