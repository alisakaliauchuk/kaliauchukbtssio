#include "etudiant.h"
#include "enseignant.h"
#include <iostream>

using namespace std;

etudiant::etudiant(string nom, string num)
    : personne(nom), numcarte(num)

{
    this->maVille = nullptr;
    cout << "constructeur d'étudiant : " << nom << " " << num << endl;
}

string etudiant::getNumcarte()
{
    return this->numcarte;
}

void etudiant::setSexe(char s)
{
    personne::setSexe(s);
}

void etudiant::ajouterCours(cours* c)
{
    tabCours.push_back(c);
}

void etudiant::afficherCours()
{
    cout << "  Cours suivis :" << endl;
    for (auto c : tabCours)
    {
        cout << "  - " << c->intitule;
        if (c->enseignantDuCours != nullptr)
            cout << " (enseignant : " << c->enseignantDuCours->getNom() << ")";
        cout << endl;
    }
}

void etudiant::afficher()
{
    string titre = (personne::getSexe() == 'F') ? "l'étudiante " : "l'étudiant ";
    string texte = titre + this->nom;
    texte += " (carte = " + this->numcarte + ")";
    cout << texte << endl;
    personne::afficher();
    if (this->maVille != nullptr)
        cout << "habite à " << this->maVille->nom << " (" << this->maVille->cp << ")" << endl;
    afficherCours();
}
