#include <iostream>
#include <vector>
#include "etudiant.h"
#include "enseignant.h"

using namespace std;

int main()
{
    //instance de Jean carte 001
    etudiant jean("Jean", "001");
    jean.setSexe('H');
    //jean.afficher();

    //instance de Jack de sexe homme
    personne jack("Jack", 'H');
    //jack.afficher();

    //instance calypso de sexe femme
    personne* calypso = new personne("calypso", 'F');
    //calypso->afficher();

    //instance de Estelle carte 002 et de sexe femme
    etudiant* estelle = new etudiant("Estelle", "002");
    estelle->setSexe('F');
    //estelle->afficher();

    vector<personne*> tabV;

    tabV.push_back(calypso);
    tabV.push_back(estelle);

    cout << "\naffichage avant virtual" << endl;
    for (auto p : tabV)
    {
        p->afficher();
    }

    tabV.push_back(&jack);
    tabV.push_back(&jean);

    cout << "\naffichage avec virtual polymorphisme" << endl;
    for (auto p : tabV)
    {
        p->afficher();
    }

    ville* reims   = new ville("Reims",   "51100");
    ville* epernay = new ville("Epernay", "51200");
    ville* paris   = new ville("Paris",   "75000");

    enseignant* gougelet  = new enseignant("Gougelet",  "SLAM", 'F', 2500.0, reims);
    enseignant* lacomblez = new enseignant("Lacomblez", "SISR", 'H', 2700.0, epernay);

    cours* cSlam  = new cours("Développement SLAM");
    cSlam->enseignantDuCours = gougelet;

    cours* cSisr  = new cours("Réseau SISR");
    cSisr->enseignantDuCours = lacomblez;

    cours* cMaths = new cours("Mathématiques");
    cMaths->enseignantDuCours = gougelet;

    etudiant* moi = new etudiant("Dupont", "003");
    moi->setSexe('F');
    moi->maVille = paris;
    moi->ajouterCours(cSlam);
    moi->ajouterCours(cMaths);

    etudiant* autreSisr = new etudiant("Martin", "004");
    autreSisr->setSexe('H');
    autreSisr->maVille = epernay;
    autreSisr->ajouterCours(cSisr);

    tabV.push_back(gougelet);
    tabV.push_back(lacomblez);
    tabV.push_back(moi);
    tabV.push_back(autreSisr);

    cout << "\nAffichage final avec enseignants et étudiants" << endl;
    for (auto p : tabV)
    {
        p->afficher();
        cout << endl;
    }

    delete calypso;
    delete estelle;
    delete reims; delete epernay; delete paris;
    delete gougelet; delete lacomblez;
    delete cSlam; delete cSisr; delete cMaths;
    delete moi; delete autreSisr;

    return 0;
}
