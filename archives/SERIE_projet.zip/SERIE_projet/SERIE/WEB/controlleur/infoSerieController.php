<?php
session_start();

if (!isset($_SESSION['utilisateur'])) {
    header('Location: index.php');
    exit;
}

require_once '../model/serieModel.php';

$numSerie = intval($_GET['num_serie'] ?? 0);

if ($numSerie <= 0) {
    header('Location: serieController.php');
    exit;
}

$serie = getInfoSerie($numSerie);

if (!$serie) {
    header('Location: serieController.php');
    exit;
}

require '../vue/infoSerie.php';
