QT += testlib
QT -= gui

CONFIG += qt console warn_on depend_includepath testcase
CONFIG -= app_bundle

TEMPLATE = app

SOURCES +=  tst_testpersonne.cpp \
            ../LYCEE/personne.cpp \
            ../LYCEE2/etudiant.cpp \
            ../LYCEE2/enseignant.cpp \
            ../LYCEE2/ville.cpp \
            ../LYCEE/cours.cpp

HEADERS += \
            ../LYCEE/personne.h \
            ../LYCEE2/etudiant.h \
            ../LYCEE2/enseignant.h \
            ../LYCEE2/ville.h \
            ../LYCEE2/cours.h \
