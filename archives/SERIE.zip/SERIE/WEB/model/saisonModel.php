<?php
// Fichier : saisonModel.php
// Rôle : fonctions pour récupérer saisons et épisodes

require_once 'connexionBDD.php';

// Récupère toutes les saisons d'une série
// Retourne un tableau de saisons
function getSaisonsDeSerie($numSerie) {
    $pdo = connexionBDD();
    $req = $pdo->prepare('
        SELECT num_saison, date_debut_tournage, date_fin_tournage
        FROM Saison
        WHERE num_serie = :num_serie
        ORDER BY num_saison
    ');
    $req->execute([':num_serie' => $numSerie]);
    return $req->fetchAll();
}

// Récupère les producteurs exécutifs d'une saison
// Retourne un tableau de noms
function getProducteursDeSaison($numSerie, $numSaison) {
    $pdo = connexionBDD();
    $req = $pdo->prepare('
        SELECT per.pnom_pers || \' \' || per.nom_pers AS producteur
        FROM Produire pr
        JOIN Producteur prod ON pr.numero    = prod.numero
        JOIN Personne  per   ON prod.code_pers = per.code_pers
        WHERE pr.num_serie  = :num_serie
          AND pr.num_saison = :num_saison
    ');
    $req->execute([':num_serie' => $numSerie, ':num_saison' => $numSaison]);
    return $req->fetchAll();
}

// Récupère les épisodes d'une saison avec titres et résumés
// Retourne un tableau d'épisodes
function getEpisodesDeSaison($numSerie, $numSaison) {
    $pdo = connexionBDD();
    $req = $pdo->prepare('
        SELECT num_epi, num_saison, num_serie,
               titre_vo, titre_vf, resume_epi
        FROM Episode
        WHERE num_serie  = :num_serie
          AND num_saison = :num_saison
        ORDER BY num_epi
    ');
    $req->execute([':num_serie' => $numSerie, ':num_saison' => $numSaison]);
    return $req->fetchAll();
}
