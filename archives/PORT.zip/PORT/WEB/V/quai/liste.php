<?php require __DIR__ . '/../layout/header.php'; ?>

<div class="page-header">
    <h1>🏗 Quais &amp; Postes</h1>
</div>

<!-- ===== QUAIS ET POSTES ===== -->
<section>
    <h2>Postes par Quai</h2>

    <?php if (empty($quaisPostes)): ?>
        <div class="alert alert-info">Aucun quai/poste enregistré.</div>
    <?php else: ?>
        <div class="table-wrapper">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>N° Quai</th>
                        <th>Nom du Quai</th>
                        <th>Tirant d'eau max (m)</th>
                        <th>N° Poste</th>
                        <th>Longueur du Poste (m)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($quaisPostes as $row): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['NumQuai']) ?></td>
                        <td><?= htmlspecialchars($row['NomQuai']) ?></td>
                        <td><?= htmlspecialchars($row['TirantDEauMax'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($row['NumPoste'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($row['LongueurPoste'] ?? '—') ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<!-- ===== TYPES DE FRET PAR QUAI ===== -->
<section style="margin-top: 2.5rem;">
    <h2>Types de Fret par Quai</h2>

    <?php if (empty($quaisFret)): ?>
        <div class="alert alert-info">Aucun type de fret associé.</div>
    <?php else: ?>
        <div class="table-wrapper">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>N° Quai</th>
                        <th>Nom du Quai</th>
                        <th>Code Type Fret</th>
                        <th>Libellé Type Fret</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($quaisFret as $row): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['NumQuai']) ?></td>
                        <td><?= htmlspecialchars($row['NomQuai']) ?></td>
                        <td><?= htmlspecialchars($row['CodeTypeFret']) ?></td>
                        <td><?= htmlspecialchars($row['LibelleTypeFret'] ?? '—') ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<?php require __DIR__ . '/../layout/footer.php'; ?>
