<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? 'Port de Caen' ?> — Port de Caen</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;600;700&family=Source+Sans+3:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/public/css/style.css">
</head>
<body>

<!-- ===== HEADER ===== -->
<header class="site-header">
    <div class="header-top">
        <span>📞 +33 (0)2 31 35 63 00</span>
        <span>✉ contact@caen.port.fr</span>
        <span>🌐 FRANÇAIS</span>
    </div>
    <div class="header-main">
        <div class="logo">
            <a href="index.php">
                <span class="logo-port">Port de</span>
                <span class="logo-caen">CAEN</span>
                <span class="logo-sub">Ouistreham</span>
            </a>
        </div>
        <nav class="main-nav">
            <a href="index.php?page=navires"<?= (($_GET['page'] ?? '') === 'navires') ? ' class="active"' : '' ?>>
                🚢 Navires
            </a>
            <a href="index.php?page=escales"<?= (($_GET['page'] ?? '') === 'escales') ? ' class="active"' : '' ?>>
                ⚓ Escales
            </a>
            <a href="index.php?page=quais"<?= (($_GET['page'] ?? '') === 'quais') ? ' class="active"' : '' ?>>
                🏗 Quais & Postes
            </a>
        </nav>
    </div>
</header>

<!-- ===== HERO BANNER ===== -->
<div class="hero-banner">
    <div class="hero-stats">
        <div class="stat"><strong>3,2M</strong><span>Tonnes</span></div>
        <div class="stat"><strong>1M</strong><span>Passagers</span></div>
        <div class="stat"><strong>12</strong><span>Grues</span></div>
        <div class="stat"><strong>10ème</strong><span>Port Français</span></div>
    </div>
</div>

<!-- ===== CONTENU PRINCIPAL ===== -->
<main class="main-content">
