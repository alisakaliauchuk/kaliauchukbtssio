<?php
define('HOST', 'localhost');
define('DBNAME', 'cartouche');
define('USER', 'postgres');
define('PASS', '1234');
?>