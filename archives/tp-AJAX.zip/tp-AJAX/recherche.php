<?php
//  recherche.php — FOURNI, ne pas modifier
//  Retourne une liste de personnes filtrée au format JSON
//  Paramètre GET : ?q=  (recherche sur nom OU prénom)
// --------------------------------------------------------------------------------------


header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

// -- Données simulées ------------------------------------------------------------------
// En production, ce tableau viendrait d'une requête SQL.
// Ici les données sont codées en dur pour le TP.
$personnes = [
    ["prenom" => "Sophie",   "nom" => "Martin",    "service" => "Informatique"],
    ["prenom" => "Lucas",    "nom" => "Marchand",  "service" => "Réseau"],
    ["prenom" => "Marie",    "nom" => "Dupont",    "service" => "Informatique"],
    ["prenom" => "Thomas",   "nom" => "Bernard",   "service" => "Développement"],
    ["prenom" => "Camille",  "nom" => "Moreau",    "service" => "RH"],
    ["prenom" => "Maxime",   "nom" => "Laurent",   "service" => "DevOps"],
    ["prenom" => "Julie",    "nom" => "Simon",     "service" => "Développement"],
    ["prenom" => "Antoine",  "nom" => "Michel",    "service" => "Réseau"],
    ["prenom" => "Laura",    "nom" => "Leroy",     "service" => "Data"],
    ["prenom" => "Pierre",   "nom" => "Roux",      "service" => "Développement"],
    ["prenom" => "Sarah",    "nom" => "David",     "service" => "Cybersécurité"],
    ["prenom" => "Mathieu",  "nom" => "Petit",     "service" => "Informatique"],
    ["prenom" => "Emma",     "nom" => "Garcia",    "service" => "Développement"],
    ["prenom" => "Nathan",   "nom" => "Perrin",    "service" => "Développement"],
    ["prenom" => "Léa",      "nom" => "Blanc",     "service" => "Informatique"],
    ["prenom" => "Hugo",     "nom" => "Fontaine",  "service" => "Développement"],
    ["prenom" => "Manon",    "nom" => "Mercier",   "service" => "QA"],
    ["prenom" => "Alice",    "nom" => "Morel",     "service" => "Développement"],
    ["prenom" => "Quentin",  "nom" => "Dupuis",    "service" => "Informatique"],
    ["prenom" => "Inès",     "nom" => "Robin",     "service" => "Développement"],
    ["prenom" => "Baptiste", "nom" => "Morin",     "service" => "Réseau"],
    ["prenom" => "Théo",     "nom" => "Lambert",   "service" => "Développement"],
    ["prenom" => "Pauline",  "nom" => "Girard",    "service" => "RH"],
    ["prenom" => "Chloé",    "nom" => "Faure",     "service" => "Data"],
    ["prenom" => "Adrien",   "nom" => "Chevalier", "service" => "Développement"],
];

// -- Récupération et nettoyage du paramètre -------------------------------------------
$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$q = mb_strtolower($q, 'UTF-8');

// Moins de 2 caractères → tableau vide
if (mb_strlen($q) < 2) {
    echo json_encode([]);
    exit;
}

// -- Filtrage : nom OU prénom commence par $q -----------------------------------------
$resultats = array_values(array_filter($personnes, function ($p) use ($q) {
    $nom    = mb_strtolower($p['nom'],    'UTF-8');
    $prenom = mb_strtolower($p['prenom'], 'UTF-8');
    return str_starts_with($nom, $q) || str_starts_with($prenom, $q);
}));

// Tri alphabétique par nom
usort($resultats, fn($a, $b) => strcmp($a['nom'], $b['nom']));

echo json_encode($resultats, JSON_UNESCAPED_UNICODE);
?>
