</main>

<footer class="site-footer">
    <div class="footer-inner">
        <div class="footer-logo">
            <span class="logo-port">Port de</span>
            <span class="logo-caen">CAEN</span>
            <span class="logo-sub">Ouistreham</span>
        </div>
        <div class="footer-links">
            <a href="/index.php?page=navires">Navires</a>
            <a href="/index.php?page=escales">Escales</a>
            <a href="/index.php?page=quais">Quais &amp; Postes</a>
        </div>
        <p class="footer-copy">&copy; <?= date('Y') ?> Port de Caen-Ouistreham</p>
    </div>
</footer>

<script src="/public/js/main.js"></script>
</body>
</html>
