<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Informations personnelles – SérieSite</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="auth-page">
    <div class="auth-carte" style="max-width:500px;">
        <h2>🎬 SérieSite</h2>
        <p class="sous-titre">Informations personnelles – Étape 2 sur 2</p>

        <?php if ($erreur !== '') : ?>
            <div class="message-erreur"><?php echo htmlspecialchars($erreur); ?></div>
        <?php endif; ?>

        <form method="POST" action="index.php">
            <input type="hidden" name="action" value="inscription_etape2">

            <p style="font-size:13px;color:#aaa;margin-bottom:14px;font-weight:bold;">Personal Details</p>

            <div class="form-groupe">
                <label for="prenom">Prénom *</label>
                <input type="text" id="prenom" name="prenom"
                       placeholder="Alice"
                       value="<?php echo htmlspecialchars($_POST['prenom'] ?? ''); ?>" required>
            </div>
            <div class="form-groupe">
                <label for="nom">Nom *</label>
                <input type="text" id="nom" name="nom"
                       placeholder="Dupont"
                       value="<?php echo htmlspecialchars($_POST['nom'] ?? ''); ?>" required>
            </div>
            <div class="form-groupe">
                <label for="adresse">Adresse *</label>
                <input type="text" id="adresse" name="adresse"
                       placeholder="10 Rue du Président Franklin Roosevelt"
                       value="<?php echo htmlspecialchars($_POST['adresse'] ?? ''); ?>" required>
            </div>
            <div class="form-groupe">
                <label for="cp">CP *</label>
                <input type="text" id="cp" name="cp"
                       placeholder="70001"
                       value="<?php echo htmlspecialchars($_POST['cp'] ?? ''); ?>" required>
            </div>
            <div class="form-groupe">
                <label for="ville">Ville *</label>
                <input type="text" id="ville" name="ville"
                       value="<?php echo htmlspecialchars($_POST['ville'] ?? ''); ?>" required>
            </div>
            <div class="form-groupe">
                <label for="tel">Numéro tél</label>
                <input type="tel" id="tel" name="tel"
                       placeholder="5123456789"
                       value="<?php echo htmlspecialchars($_POST['tel'] ?? ''); ?>">
            </div>

            <p style="font-size:13px;color:#aaa;margin:16px 0 14px;font-weight:bold;">Détails paiement</p>

            <div class="form-groupe">
                <label for="num_carte">Numéro carte bancaire</label>
                <input type="text" id="num_carte" name="num_carte"
                       placeholder="4001 2000 3000 4000" maxlength="19"
                       value="<?php echo htmlspecialchars($_POST['num_carte'] ?? ''); ?>">
            </div>
            <div class="form-groupe">
                <label for="date_exp">Date d'expiration (MM/AA)</label>
                <input type="text" id="date_exp" name="date_exp"
                       placeholder="01/25" maxlength="5"
                       value="<?php echo htmlspecialchars($_POST['date_exp'] ?? ''); ?>">
            </div>
            <div class="form-groupe">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv"
                       placeholder="•••" maxlength="4"
                       value="<?php echo htmlspecialchars($_POST['cvv'] ?? ''); ?>">
            </div>

            <button type="submit" class="btn-complet">Continuer</button>
        </form>
    </div>
</div>
</body>
</html>
