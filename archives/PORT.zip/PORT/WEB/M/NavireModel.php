<?php
require_once __DIR__ . '/Database.php';

class NavireModel
{

    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function getAll(): array
    {
        $stmt = $this->db->query('SELECT * FROM liste_navire ORDER BY nolloyds');
        return $stmt->fetchAll();
    }

    public function getById(int $id): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM liste_navire WHERE nolloyds = :id');
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function searchByName(string $nom): array
    {
        $stmt = $this->db->prepare(
            "SELECT * FROM liste_navire WHERE LOWER(nomnavire) LIKE LOWER(:nom) ORDER BY nomnavire"
        );
        $stmt->execute([':nom' => '%' . $nom . '%']);
        return $stmt->fetchAll();
    }
}
