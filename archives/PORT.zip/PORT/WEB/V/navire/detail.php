<?php require __DIR__ . '/../layout/header.php'; ?>

<div class="page-header">
    <a href="index.php?page=navires" class="btn btn-secondary">← Retour à la liste</a>
    <h1>🚢 <?= htmlspecialchars($navire['nomnavire']) ?></h1>
</div>

<div class="fiche-navire">
    <div class="fiche-section">
        <h2>Caractéristiques du navire</h2>
        <div class="fiche-grid">
            <div class="fiche-row">
                <span class="fiche-label">N° Lloyd's</span>
                <span class="fiche-value"><?= htmlspecialchars($navire['nolloyds']) ?></span>
            </div>
            <div class="fiche-row">
                <span class="fiche-label">Nom</span>
                <span class="fiche-value"><?= htmlspecialchars($navire['nomnavire']) ?></span>
            </div>
            <div class="fiche-row">
                <span class="fiche-label">Type</span>
                <span class="fiche-value"><?= htmlspecialchars($navire['typenavire'] ?? '—') ?></span>
            </div>
            <div class="fiche-row">
                <span class="fiche-label">Pavillon</span>
                <span class="fiche-value"><?= htmlspecialchars($navire['pavillon'] ?? '—') ?></span>
            </div>
            <div class="fiche-row">
                <span class="fiche-label">Longueur</span>
                <span class="fiche-value"><?= htmlspecialchars($navire['longueur'] ?? '—') ?> m</span>
            </div>
            <div class="fiche-row">
                <span class="fiche-label">Largeur</span>
                <span class="fiche-value"><?= htmlspecialchars($navire['largeur'] ?? '—') ?> m</span>
            </div>
            <div class="fiche-row">
                <span class="fiche-label">Tirant d'eau</span>
                <span class="fiche-value"><?= htmlspecialchars($navire['tirantdeau'] ?? '—') ?> m</span>
            </div>
            <div class="fiche-row">
                <span class="fiche-label">Capacité</span>
                <span class="fiche-value"><?= htmlspecialchars($navire['capacite'] ?? '—') ?> m³</span>
            </div>
            <div class="fiche-row">
                <span class="fiche-label">Armateur</span>
                <span class="fiche-value"><?= htmlspecialchars($navire['nomarmateur'] ?? '—') ?></span>
            </div>
            <div class="fiche-row">
                <span class="fiche-label">Propulsé</span>
                <span class="fiche-value">
                    <?= $navire['propulse']
                        ? '<span class="badge badge-yes">Oui</span>'
                        : '<span class="badge badge-no">Non</span>' ?>
                </span>
            </div>
        </div>
    </div>
</div>

<div class="section-escales">
    <h2>⚓ Escales de ce navire</h2>

    <?php if (empty($escales)): ?>
        <div class="alert alert-info">Aucune escale enregistrée pour ce navire.</div>
    <?php else: ?>
        <div class="table-wrapper">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>N° Escale</th>
                        <th>Arrivée</th>
                        <th>Départ</th>
                        <th>Provenance</th>
                        <th>Destination</th>
                        <th>Import / Export</th>
                        <th>Quai</th>
                        <th>Poste</th>
                        <th>Confirmée</th>
                        <th>Fiche</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($escales as $e): ?>
                    <tr>
                        <td><?= htmlspecialchars($e['numescale']) ?></td>
                        <td><?= htmlspecialchars($e['datearrivee'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($e['datedepart'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($e['provenance'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($e['destination'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($e['importexport'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($e['nomquai'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($e['numposte'] ?? '—') ?></td>
                        <td>
                            <?= $e['escaleconfirmee']
                                ? '<span class="badge badge-yes">Oui</span>'
                                : '<span class="badge badge-no">Non</span>' ?>
                        </td>
                        <td>
                            <a href="index.php?page=escales&action=detail&id=<?= $e['numescale'] ?>"
                               class="btn btn-escale">escale</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/../layout/footer.php'; ?>