CREATE TABLE Personne (
    code_pers INT PRIMARY KEY,
    nom_pers VARCHAR(50),
    pnom_pers VARCHAR(50)
);

CREATE TABLE Producteur (
    numero INT PRIMARY KEY,
    code_pers INT,
    FOREIGN KEY (code_pers) REFERENCES Personne(code_pers)
);

CREATE TABLE Createur (
    numero INT PRIMARY KEY,
    code_pers INT,
    FOREIGN KEY (code_pers) REFERENCES Personne(code_pers)
);

CREATE TABLE Scenariste (
    numero INT PRIMARY KEY,
    code_pers INT,
    FOREIGN KEY (code_pers) REFERENCES Personne(code_pers)
);

CREATE TABLE Realisateur (
    numero INT PRIMARY KEY,
    code_pers INT,
    FOREIGN KEY (code_pers) REFERENCES Personne(code_pers)
);

CREATE TABLE Acteur (
    numero INT PRIMARY KEY,
    code_pers INT,
    FOREIGN KEY (code_pers) REFERENCES Personne(code_pers)
);

CREATE TABLE Doubleur (
    numero INT PRIMARY KEY,
    code_pers INT,
    FOREIGN KEY (code_pers) REFERENCES Personne(code_pers)
);

CREATE TABLE Genre (
    num_genre INT PRIMARY KEY,
    lib_genre VARCHAR(50)
);

CREATE TABLE Chaine (
    num_chaine INT PRIMARY KEY,
    lib_chaine VARCHAR(50)
);

CREATE TABLE Pays (
    num_pays INT PRIMARY KEY,
    nom_pays VARCHAR(50)
);

CREATE TABLE Serie (
    num_serie INT PRIMARY KEY,
    titre_serieVF VARCHAR(100),
    titre_serieVO VARCHAR(100),
    num_pays INT,
    numero INT,
    num_genre INT,
    annee_creation INT,
    FOREIGN KEY (num_pays) REFERENCES Pays(num_pays),
    FOREIGN KEY (numero) REFERENCES Createur(numero),
    FOREIGN KEY (num_genre) REFERENCES Genre(num_genre)
);

CREATE TABLE Saison (
    num_serie INT,
    num_saison INT CHECK (num_saison > 0),
    date_debut_tournage DATE,
    date_fin_tournage DATE,
    PRIMARY KEY (num_serie, num_saison),
    FOREIGN KEY (num_serie) REFERENCES Serie(num_serie),
    CHECK (date_debut_tournage < date_fin_tournage)
);

CREATE TABLE Episode (
    num_epi INT CHECK (num_epi > 0),
    num_serie INT,
    num_saison INT,
    PRIMARY KEY (num_epi, num_serie, num_saison),
    FOREIGN KEY (num_serie, num_saison) REFERENCES Saison(num_serie, num_saison)
);

CREATE TABLE Personnage (
    desc_perso VARCHAR(100),
    code_pers INT PRIMARY KEY,
    FOREIGN KEY (code_pers) REFERENCES Personne(code_pers)
);

CREATE TABLE Position (
    num_pos INT PRIMARY KEY,
    lib_pos VARCHAR(50)
);

CREATE TABLE Interprete (
    code_pers INT,
    num_serie INT,
    num_saison INT,
    num_epi INT,
    guest_star VARCHAR(20),
    numero INT,
    numero_1 INT,
    PRIMARY KEY (code_pers, num_serie, num_saison, num_epi),
    FOREIGN KEY (code_pers) REFERENCES Personnage(code_pers),
    FOREIGN KEY (num_serie, num_saison, num_epi) REFERENCES Episode(num_serie, num_saison, num_epi),
    FOREIGN KEY (numero) REFERENCES Doubleur(numero),
    FOREIGN KEY (numero_1) REFERENCES Acteur(numero)
);

CREATE TABLE Attacher (
    code_pers INT,
    num_pos INT,
    PRIMARY KEY (code_pers, num_pos),
    FOREIGN KEY (code_pers) REFERENCES Personnage(code_pers),
    FOREIGN KEY (num_pos) REFERENCES Position(num_pos)
);

CREATE TABLE Diffuser (
    num_serie INT,
    num_chaine INT,
    PRIMARY KEY (num_serie, num_chaine),
    FOREIGN KEY (num_serie) REFERENCES Serie(num_serie),
    FOREIGN KEY (num_chaine) REFERENCES Chaine(num_chaine)
);

CREATE TABLE Produire (
    numero INT,
    num_serie INT,
    PRIMARY KEY (numero, num_serie),
    FOREIGN KEY (numero) REFERENCES Producteur(numero),
    FOREIGN KEY (num_serie) REFERENCES Serie(num_serie)
);

CREATE TABLE Scenariser (
    numero INT,
    num_serie INT,
    num_saison INT,
    num_epi INT,
    PRIMARY KEY (numero, num_serie, num_saison, num_epi),
    FOREIGN KEY (numero) REFERENCES Scenariste(numero),
    FOREIGN KEY (num_serie, num_saison, num_epi) REFERENCES Episode(num_serie, num_saison, num_epi)
);

CREATE TABLE Realiser (
    numero INT,
    num_serie INT,
    num_saison INT,
    num_epi INT,
    PRIMARY KEY (numero, num_serie, num_saison, num_epi),
    FOREIGN KEY (numero) REFERENCES Realisateur(numero),
    FOREIGN KEY (num_serie, num_saison, num_epi) REFERENCES Episode(num_serie, num_saison, num_epi)
);

CREATE TABLE Utilisateur (
    id_utilisateur INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    identifiant VARCHAR(100) UNIQUE NOT NULL,
    mot_de_passe VARCHAR(255) NOT NULL,
    prenom VARCHAR(50),
    nom VARCHAR(50),
    adresse VARCHAR(255),
    cp VARCHAR(10),
    ville VARCHAR(100),
    tel VARCHAR(20),
    num_carte VARCHAR(50),
    date_exp VARCHAR(10),
    cvv VARCHAR(4)
);

INSERT INTO
    Genre (num_genre, lib_genre)
VALUES
    (1, 'Drame médical'),
    (2, 'Science-Fiction'),
    (3, 'Policier'),
    (4, 'Comédie'),
    (5, 'Thriller');

INSERT INTO
    Pays (num_pays, nom_pays)
VALUES
    (1, 'États-Unis'),
    (2, 'Royaume-Uni'),
    (3, 'France');

INSERT INTO
    Chaine (num_chaine, lib_chaine)
VALUES
    (1, 'Fox'),
    (2, 'NBC'),
    (3, 'TF1'),
    (4, 'Canal+'),
    (5, 'HBO');

INSERT INTO
    Personne (code_pers, nom_pers, pnom_pers)
VALUES
    (1, 'Shore', 'David'),
    (2, 'Abrams', 'J.J.'),
    (3, 'Gilligan', 'Vince'),
    (4, 'Chase', 'David'),
    (5, 'Weiner', 'Matthew');

INSERT INTO
    Createur (numero, code_pers)
VALUES
    (1, 1),
    (2, 2),
    (3, 3),
    (4, 4),
    (5, 5);

INSERT INTO
    Serie (num_serie,titre_serieVF,titre_serieVO,annee_creation,num_pays,numero,num_genre)
VALUES
    (1,'Dr House','House M.D.',2004,1,1,1),
    (2,'Lost','Lost',2004,1,2,2),
    (3,'Breaking Bad','Breaking Bad',2008,1,3,5),
    (4,'Les Sopranos','The Sopranos',1999,1,4,3),
    (5,'Mad Men','Mad Men',2007,1,5,4);

INSERT INTO
    Diffuser (num_serie, num_chaine)
VALUES
    (1, 1),
    (1, 3),
    (2, 2),
    (3, 2),
    (4, 5),
    (5, 5);

INSERT INTO
    Saison (num_serie,num_saison,date_debut_tournage,date_fin_tournage)
VALUES
    (1, 1, '2004-02-01', '2004-10-30'),
    (1, 2, '2005-02-01', '2005-11-15'),
    (1, 3, '2006-01-15', '2006-12-01'),
    (1, 4, '2007-06-01', '2008-04-20'),
    (1, 5, '2008-07-01', '2009-05-10'),
    (1, 6, '2009-06-01', '2010-05-17'),
    (1, 7, '2010-06-01', '2011-05-23'),
    (1, 8, '2011-06-01', '2012-05-21');

INSERT INTO
    Episode (num_epi, num_serie, num_saison)
VALUES
    (1, 1, 1),
    (2, 1, 1),
    (3, 1, 1),
    (4, 1, 1),
    (5, 1, 1),
    (6, 1, 1),
    (7, 1, 1),
    (8, 1, 1),
    (9, 1, 1),
    (10, 1, 1),
    (11, 1, 1),
    (12, 1, 1),
    (13, 1, 1),
    (14, 1, 1),
    (15, 1, 1),
    (16, 1, 1),
    (17, 1, 1),
    (18, 1, 1),
    (19, 1, 1),
    (20, 1, 1),
    (21, 1, 1),
    (22, 1, 1);

INSERT INTO
    Episode (num_epi, num_serie, num_saison)
VALUES
    (1, 1, 2),
    (2, 1, 2),
    (3, 1, 2),
    (4, 1, 2),
    (5, 1, 2),
    (6, 1, 2),
    (7, 1, 2),
    (8, 1, 2),
    (9, 1, 2),
    (10, 1, 2),
    (11, 1, 2),
    (12, 1, 2),
    (13, 1, 2),
    (14, 1, 2),
    (15, 1, 2),
    (16, 1, 2),
    (17, 1, 2),
    (18, 1, 2),
    (19, 1, 2),
    (20, 1, 2),
    (21, 1, 2),
    (22, 1, 2),
    (23, 1, 2),
    (24, 1, 2);

INSERT INTO
    Episode (num_epi, num_serie, num_saison)
VALUES
    (1, 1, 3),
    (2, 1, 3),
    (3, 1, 3),
    (4, 1, 3),
    (5, 1, 3),
    (6, 1, 3),
    (7, 1, 3),
    (8, 1, 3),
    (9, 1, 3),
    (10, 1, 3),
    (11, 1, 3),
    (12, 1, 3),
    (13, 1, 3),
    (14, 1, 3),
    (15, 1, 3),
    (16, 1, 3),
    (17, 1, 3),
    (18, 1, 3),
    (19, 1, 3),
    (20, 1, 3),
    (21, 1, 3),
    (22, 1, 3),
    (23, 1, 3),
    (24, 1, 3);

INSERT INTO
    Episode (num_epi, num_serie, num_saison)
VALUES
    (1, 1, 4),
    (2, 1, 4),
    (3, 1, 4),
    (4, 1, 4),
    (5, 1, 4),
    (6, 1, 4),
    (7, 1, 4),
    (8, 1, 4),
    (9, 1, 4),
    (10, 1, 4),
    (11, 1, 4),
    (12, 1, 4),
    (13, 1, 4),
    (14, 1, 4),
    (15, 1, 4),
    (16, 1, 4);

INSERT INTO
    Episode (num_epi, num_serie, num_saison)
VALUES
    (1, 1, 5),
    (2, 1, 5),
    (3, 1, 5),
    (4, 1, 5),
    (5, 1, 5),
    (6, 1, 5),
    (7, 1, 5),
    (8, 1, 5),
    (9, 1, 5),
    (10, 1, 5),
    (11, 1, 5),
    (12, 1, 5),
    (13, 1, 5),
    (14, 1, 5),
    (15, 1, 5),
    (16, 1, 5),
    (17, 1, 5),
    (18, 1, 5),
    (19, 1, 5),
    (20, 1, 5),
    (21, 1, 5),
    (22, 1, 5),
    (23, 1, 5),
    (24, 1, 5);

INSERT INTO
    Episode (num_epi, num_serie, num_saison)
VALUES
    (1, 1, 6),
    (2, 1, 6),
    (3, 1, 6),
    (4, 1, 6),
    (5, 1, 6),
    (6, 1, 6),
    (7, 1, 6),
    (8, 1, 6),
    (9, 1, 6),
    (10, 1, 6),
    (11, 1, 6),
    (12, 1, 6),
    (13, 1, 6),
    (14, 1, 6),
    (15, 1, 6),
    (16, 1, 6),
    (17, 1, 6),
    (18, 1, 6),
    (19, 1, 6),
    (20, 1, 6),
    (21, 1, 6),
    (22, 1, 6);

INSERT INTO
    Episode (num_epi, num_serie, num_saison)
VALUES
    (1, 1, 7),
    (2, 1, 7),
    (3, 1, 7),
    (4, 1, 7),
    (5, 1, 7),
    (6, 1, 7),
    (7, 1, 7),
    (8, 1, 7),
    (9, 1, 7),
    (10, 1, 7),
    (11, 1, 7),
    (12, 1, 7),
    (13, 1, 7),
    (14, 1, 7),
    (15, 1, 7),
    (16, 1, 7),
    (17, 1, 7),
    (18, 1, 7),
    (19, 1, 7),
    (20, 1, 7),
    (21, 1, 7),
    (22, 1, 7),
    (23, 1, 7);

INSERT INTO
    Episode (num_epi, num_serie, num_saison)
VALUES
    (1, 1, 8),
    (2, 1, 8),
    (3, 1, 8),
    (4, 1, 8),
    (5, 1, 8),
    (6, 1, 8),
    (7, 1, 8),
    (8, 1, 8),
    (9, 1, 8),
    (10, 1, 8),
    (11, 1, 8),
    (12, 1, 8),
    (13, 1, 8),
    (14, 1, 8),
    (15, 1, 8),
    (16, 1, 8),
    (17, 1, 8),
    (18, 1, 8),
    (19, 1, 8),
    (20, 1, 8),
    (21, 1, 8),
    (22, 1, 8);