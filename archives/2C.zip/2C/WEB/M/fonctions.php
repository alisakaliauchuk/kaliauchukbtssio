<?php
include_once("client.php");
include_once("facture.php");
include_once("ligneFacture.php");
include_once("../myparam.inc.php");

function getConnexion() {
    return new PDO('pgsql:host='.HOST.';port=5432;dbname='.DBNAME, USER, PASS);
}

function getAllFactures(): array {
    $pdo = getConnexion();

    $sql = "SELECT id_facture, date_facture, nom_client
            FROM vue_liste_factures
            ORDER BY date_facture DESC";

    $req = $pdo->query($sql);
    if (!$req) return [];

    $tab = [];
    while ($ligne = $req->fetch(PDO::FETCH_ASSOC)) {
        $client = new Client(0, $ligne['nom_client'], "", "", "", "");

        $fact = new Facture(
            intval($ligne['id_facture']),
            $ligne['date_facture'],
            $client
        );
        $tab[] = $fact;
    }
    return $tab;
}

function getFactureById(int $id): ?Facture {
    $pdo = getConnexion();

    $sql = "SELECT id_facture, date_facture, id_client, nom, adresse, cp, ville, tel
            FROM vue_client_facture
            WHERE id_facture = :id";

    $req = $pdo->prepare($sql);
    $req->execute(["id" => $id]);

    $ligne = $req->fetch(PDO::FETCH_ASSOC);
    if (!$ligne) return null;

    $client = new Client(
        intval($ligne['id_client']),
        $ligne['nom'],
        $ligne['adresse'],
        $ligne['cp'],
        $ligne['ville'],
        $ligne['tel']
    );

    $date = $ligne['date_facture'] ?? "";
    return new Facture(intval($ligne['id_facture']), $date, $client);
}

function getDetailFacture(int $id): array {
    $pdo = getConnexion();

    $sql = "SELECT image, reference, designation, type, quantite, tarif_facture, montant_ht
            FROM vue_detail_facture
            WHERE id_facture = :id
            ORDER BY reference";

    $req = $pdo->prepare($sql);
    $req->execute(["id" => $id]);

    $tab = [];
    while ($ligne = $req->fetch(PDO::FETCH_ASSOC)) {
        $lf = new LigneFacture(
            $ligne['image'],
            $ligne['reference'],
            $ligne['designation'],
            $ligne['type'],
            intval($ligne['quantite']),
            floatval($ligne['tarif_facture'])
        );
        $tab[] = $lf;
    }
    return $tab;
}

function getAvoirsFacture(int $id): array {
    return [];
}
?>
