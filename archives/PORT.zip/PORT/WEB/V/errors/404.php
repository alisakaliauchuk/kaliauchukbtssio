<?php require __DIR__ . '/../layout/header.php'; ?>

<div class="error-page">
    <div class="error-code">404</div>
    <div class="error-msg">Page introuvable</div>
    <a href="/index.php" class="btn btn-primary">Retour à l'accueil</a>
</div>

<?php require __DIR__ . '/../layout/footer.php'; ?>
