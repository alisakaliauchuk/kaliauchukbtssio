CREATE DATABASE Port;

CREATE ROLE port_admin;
GRANT ALL ON DATABASE "Port" TO port_admin;

CREATE ROLE port_user;
GRANT SELECT ON liste_navire TO port_user;