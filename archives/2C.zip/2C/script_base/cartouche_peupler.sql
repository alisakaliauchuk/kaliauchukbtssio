begin transaction;

insert into client (id_client,nom, adresse, cp, ville, tel) values (1, 'DUMOTIER Philippe', '24 rue de la Baltique', '51100', 'REIMS', '0326101023');
insert into client (id_client,nom, adresse, cp, ville, tel) values (2, 'BROCCA Georges', '15 allee des Béarnais', '51150', 'VITRY LE FRANCOIS', '0326424233');
insert into client (id_client,nom, adresse, cp, ville, tel) values (3, 'SOCIETE DU PAYSAGE REMOIS', '14 rue Lanterneau', '51100', 'REIMS', '0326121287');
insert into client (id_client,nom, adresse, cp, ville, tel) values (4, 'PALAISEAU CONSTRUCTION', '1, rue de la Méditerranée', '51140', 'ROMAIN', '0326788954');
insert into client (id_client,nom, adresse, cp, ville, tel) values (5, 'POCLAIN Jean-Michel', '5 place des Oiseaux', '51200', 'FISMES', '0326535655');
insert into client(id_client, nom, adresse, cp, ville, tel) values (10, NULL, '1 rue Test', '00000', 'TESTVILLE', '0123456789');

insert into cartouche(reference, designation) values ('B204', 'BROTHER 2040CL 1400 copies');
insert into cartouche(reference, designation) values ('B205', 'BROTHER 2040CL 2500 copies');
insert into cartouche(reference, designation) values ('B40L', 'BROTHER 40HL');
insert into cartouche(reference, designation) values ('B60L', 'BROTHER 60HL');
insert into cartouche(reference, designation) values ('CA18', 'CANON 1804CF');
insert into cartouche(reference, designation) values ('CA23', 'CANON 23CX');
insert into cartouche(reference, designation) values ('E204', 'EPSON 2040CL 1200 copies');
insert into cartouche(reference, designation) values ('E205', 'EPSON 2040CL longue durée');
insert into cartouche(reference, designation) values ('HPX1', 'HP XAB');
insert into cartouche(reference, designation) values ('HPXR', 'HP XER');
insert into cartouche(reference, designation) values ('SA12', 'SAMSUNG G 240');
insert into cartouche(reference, designation) values ('SA14', 'SAMSUNG GT 240');

insert into cartouche_typee(reference, type, tarif) values ('B204', 'N', 87.20);
insert into cartouche_typee(reference, type, tarif) values ('B204', 'R', 62.20);
insert into cartouche_typee(reference, type, tarif) values ('B205', 'N', 111.40);
insert into cartouche_typee(reference, type, tarif) values ('B205', 'R', 84.00);
insert into cartouche_typee(reference, type, tarif) values ('B40L', 'N', 45.00);
insert into cartouche_typee(reference, type, tarif) values ('B60L', 'N', 54.00);
insert into cartouche_typee(reference, type, tarif) values ('B60L', 'R', 46.00);
insert into cartouche_typee(reference, type, tarif) values ('CA18', 'R', 52.50);
insert into cartouche_typee(reference, type, tarif) values ('CA23', 'N', 81.00);
insert into cartouche_typee(reference, type, tarif) values ('CA23', 'R', 64.80);
insert into cartouche_typee(reference, type, tarif) values ('E204', 'N', 114.00);
insert into cartouche_typee(reference, type, tarif) values ('E205', 'R', 104.00);
insert into cartouche_typee(reference, type, tarif) values ('HPX1', 'N', 124.00);
insert into cartouche_typee(reference, type, tarif) values ('HPX1', 'R', 103.40);
insert into cartouche_typee(reference, type, tarif) values ('HPXR', 'N', 124.00);
insert into cartouche_typee(reference, type, tarif) values ('SA12', 'N', 78.80);
insert into cartouche_typee(reference, type, tarif) values ('SA12', 'R', 59.70);
insert into cartouche_typee(reference, type, tarif) values ('SA14', 'N', 65.00);
insert into cartouche_typee(reference, type, tarif) values ('SA14', 'R', 44.00);
insert into cartouche_typee(reference, type, tarif) values ('TEST1', 'N', -50.00);

insert into client_regulier(id_client, nom_contact) values (3, 'TISSOT Pierre');
insert into client_regulier(id_client, nom_contact) values (1, 'DUMOTIER Philippe');
SELECT * FROM client_regulier WHERE id_client = 1;

insert into contrat(id_contrat, date_contrat, duree, id_client) values (1,'2021-01-01',60,3);	
insert into contrat(id_contrat, date_contrat, duree, id_client) values (2,'2021-03-01',90,3);	
insert into contrat(id_contrat, date_contrat, duree, id_client) values (3,'2021-06-01',90,3);
insert into contrat(id_contrat, date_contrat, duree, id_client) values (10, '2025-01-01', 50, 3);

insert into concerner(reference, type, id_contrat, quantite_mini, tarif)  values ('B204', 'N', 1, 5, 78.40);
insert into concerner(reference, type, id_contrat, quantite_mini, tarif)  values ('B204', 'R', 1, 8, 49.40);
insert into concerner( reference, type, id_contrat, quantite_mini, tarif)  values ('B205', 'N', 1, 5, 98.60);
insert into concerner( reference, type, id_contrat, quantite_mini, tarif)  values ('B205', 'R', 1, 8, 67.90);
insert into concerner( reference, type, id_contrat, quantite_mini, tarif)  values ('B204', 'R', 2, 10, 45.60);
insert into concerner( reference, type, id_contrat, quantite_mini, tarif)  values ('B205', 'R', 2, 10, 62.90);
insert into concerner( reference, type, id_contrat, quantite_mini, tarif)  values ('B204', 'R', 3, 10, 45.40);
insert into concerner( reference, type, id_contrat, quantite_mini, tarif)  values ('B205', 'R', 3, 10, 61.90);
insert into concerner(reference, type, id_contrat, quantite_mini, tarif) values ('B204', 'N', 1, -5, 50.00);
insert into concerner(reference, type, id_contrat, quantite_mini, tarif) values ('B204', 'N', 1, 2000, 50.00);

insert into facture(id_facture, date_facture, id_client) values (123,'2020-12-04', 3);
insert into facture(id_facture, date_facture, id_client) values (124,'2021-02-11', 3);
insert into facture(id_facture, date_facture, id_client) values (125,'2021-02-14', 1);
insert into facture(id_facture, date_facture, id_client) values (126,'2021-02-16', 2);
insert into facture(id_facture, date_facture, id_client) values (127,'2021-04-21', 3);
insert into facture(id_facture, date_facture, id_client) values (128,'2021-05-02', 3);
insert into facture(id_facture, date_facture, id_client) values (129,'2021-06-26', 2);
insert into facture(id_facture, date_facture, id_client) values (130,'2021-07-16', 4);
insert into facture(id_facture, date_facture, id_client) values (131,'2021-08-16', 2);

insert into facturer(id_facture, reference, type, quantite) values (123, 'B204', 'N', 2);
insert into facturer(id_facture, reference, type, quantite) values (123, 'B204', 'R', 2);
insert into facturer(id_facture, reference, type, quantite) values (124, 'B204', 'R', 8);
insert into facturer(id_facture, reference, type, quantite) values (124, 'B205', 'N', 5);
insert into facturer(id_facture, reference, type, quantite) values (124, 'CA23', 'R', 1);
insert into facturer(id_facture, reference, type, quantite) values (125, 'SA14', 'N', 4);
insert into facturer(id_facture, reference, type, quantite) values (126, 'HPX1', 'N', 1);
insert into facturer(id_facture, reference, type, quantite) values (126, 'HPXR', 'N', 1);
insert into facturer(id_facture, reference, type, quantite) values (126, 'B60L', 'N', 4);
insert into facturer(id_facture, reference, type, quantite) values (127, 'B204', 'R', 10);
insert into facturer(id_facture, reference, type, quantite) values (127, 'CA23', 'R', 1);
insert into facturer(id_facture, reference, type, quantite) values (128, 'B204', 'N', 6);
insert into facturer(id_facture, reference, type, quantite) values (128, 'B204', 'R', 12);
insert into facturer(id_facture, reference, type, quantite) values (129, 'B60L', 'N', 5);
insert into facturer(id_facture, reference, type, quantite) values (129, 'B60L', 'R', 5);
insert into facturer(id_facture, reference, type, quantite) values (130, 'B40L', 'N', 4);
insert into facturer(id_facture, reference, type, quantite) values (130, 'SA14', 'R', 4);
insert into facturer(id_facture, reference, type, quantite) values (131, 'B60L', 'N', 2);
insert into facturer(id_facture, reference, type, quantite) values (131, 'B60L', 'R', 7);
insert into facturer(id_facture, reference, type, quantite) values (131, 'HPXR', 'N', 1);
insert into facturer(id_facture, reference, type, quantite) values (123, 'B204', 'N', -5);
insert into facturer(id_facture, reference, type, quantite) values (123, 'B204', 'N', 2000);

commit;


UPDATE cartouche SET image = 'TN2000_main.jpg' WHERE reference = 'B204';
UPDATE cartouche SET image = 'TN-2005.jpg' WHERE reference = 'B205';
UPDATE cartouche SET image = 'TN-2220.jpg' WHERE reference = 'B40L';
UPDATE cartouche SET image = 'TN-2320.jpg' WHERE reference = 'B60L';
UPDATE cartouche SET image = 'Canon_BCI-24.jpg' WHERE reference = 'CA18';
UPDATE cartouche SET image = 'Canon_BCI-23.jpg' WHERE reference = 'CA23';
UPDATE cartouche SET image = 'Epson_T0711.jpg' WHERE reference = 'E204';
UPDATE cartouche SET image = 'Epson_XL.jpg' WHERE reference = 'E205';
UPDATE cartouche SET image = 'HP_1.jpg' WHERE reference = 'HPX1';
UPDATE cartouche SET image = 'HP_2.jpg' WHERE reference = 'HPXR';
UPDATE cartouche SET image = 'Samsung_1.jpg' WHERE reference = 'SA12';
UPDATE cartouche SET image = 'Samsung_2.jpg' WHERE reference = 'SA14';
