CREATE VIEW annexe1Vue AS
SELECT
s.titre_serieVO,
s.titre_serieVF,
g.lib_genre,
p.nom_pays,
per.nom_pers AS createur_nom,
per.pnom_pers AS createur_prenom
FROM Serie s
JOIN Genre g ON s.num_genre = g.num_genre
JOIN Pays p ON s.num_pays = p.num_pays
JOIN Createur c ON s.numero = c.numero
JOIN Personne per ON c.code_pers = per.code_pers;

CREATE VIEW annexe2Vue AS
SELECT
c.lib_chaine,
p.nom_pays,
s.titre_serieVO
FROM Diffuser d
JOIN Chaine c ON d.num_chaine = c.num_chaine
JOIN Serie s ON d.num_serie = s.num_serie
JOIN Pays p ON s.num_pays = p.num_pays;

CREATE VIEW annexe3Vue AS
SELECT
s.titre_serieVO,
sa.num_saison
FROM Saison sa
JOIN Serie s ON sa.num_serie = s.num_serie;

CREATE VIEW annexe4Vue AS
SELECT
e.num_epi,
e.num_saison,
s.titre_serieVO
FROM Episode e
JOIN Serie s ON e.num_serie = s.num_serie;

CREATE VIEW annexe5Vue AS
SELECT
pe.desc_perso,
p.nom_pers,
p.pnom_pers
FROM Personnage pe
JOIN Personne p ON pe.code_pers = p.code_pers;