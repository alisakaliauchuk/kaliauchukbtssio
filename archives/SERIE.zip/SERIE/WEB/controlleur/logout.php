<?php
// Fichier : logout.php
// Rôle : déconnecte l'utilisateur

session_start();
session_destroy();
header('Location: index.php');
exit;
