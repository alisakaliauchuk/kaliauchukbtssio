<?php
require_once __DIR__ . '/../M/NavireModel.php';

class NavireController {

    private NavireModel $model;

    public function __construct() {
        $this->model = new NavireModel();
    }

    public function index(): void {
        $search  = trim($_GET['search'] ?? '');
        $navires = $search !== ''
            ? $this->model->searchByName($search)
            : $this->model->getAll();

        $pageTitle = 'Liste des Navires';
        require __DIR__ . '/../V/navire/liste.php';
    }

    public function detail(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $navire = $this->model->getById($id);

        if (!$navire) {
            http_response_code(404);
            $pageTitle = 'Navire introuvable';
            require __DIR__ . '/../V/errors/404.php';
            return;
        }

        require_once __DIR__ . '/../M/EscaleModel.php';
        $escaleModel = new EscaleModel();
        $escales = $escaleModel->getByNavire($id);

        $pageTitle = htmlspecialchars($navire['NomNavire']);
        require __DIR__ . '/../V/navire/detail.php';
    }
}
