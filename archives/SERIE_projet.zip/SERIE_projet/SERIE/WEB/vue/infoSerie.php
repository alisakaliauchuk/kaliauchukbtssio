<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($serie['titre_serievf']); ?> – Série Site</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header>
    <a href="serieController.php" class="logo">Série Site</a>
    <nav>
        <a href="serieController.php">Catalogue</a>
        <a href="logout.php">Déconnexion</a>
    </nav>
</header>

<div class="contenu">

    <p class="fil-ariane">
        <a href="serieController.php">Catalogue</a> &rsaquo;
        <?php echo htmlspecialchars($serie['titre_serievf']); ?>
    </p>

    <h1><?php echo htmlspecialchars($serie['titre_serievf']); ?></h1>

    <div class="info-serie">

        <img src="../assets/images/<?php echo intval($serie['num_serie']); ?>.jpg"
             onerror="this.src='../assets/images/default.jpg'"
             alt="Affiche de <?php echo htmlspecialchars($serie['titre_serievf']); ?>">

        <div class="info-serie-texte">
            <p>
                <span class="label">Titre VO</span>
                <?php echo htmlspecialchars($serie['titre_serievo']); ?>
            </p>
            <p>
                <span class="label">Genre</span>
                <?php echo htmlspecialchars($serie['lib_genre']); ?>
            </p>
            <p>
                <span class="label">Pays</span>
                <?php echo htmlspecialchars($serie['nom_pays']); ?>
            </p>
            <p>
                <span class="label">Année de création</span>
                <?php echo htmlspecialchars($serie['annee_creation'] ?? '—'); ?>
            </p>
            <p>
                <span class="label">Créateur</span>
                <?php echo htmlspecialchars($serie['createur_prenom'] . ' ' . $serie['createur_nom']); ?>
            </p>
            <?php if (!empty($serie['chaines'])) : ?>
            <p>
                <span class="label">Diffusé sur</span>
                <?php echo htmlspecialchars($serie['chaines']); ?>
            </p>
            <?php endif; ?>

            <br>
            <a href="saisonController.php?num_serie=<?php echo intval($serie['num_serie']); ?>&num_saison=1"
               class="btn btn-rouge">📺 Voir les saisons</a>

            <a href="serieController.php" class="btn btn-gris" style="margin-left:10px;">← Retour</a>
        </div>
    </div>
</div>

</body>
</html>
