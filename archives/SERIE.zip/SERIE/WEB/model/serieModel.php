<?php

require_once 'connexionBDD.php';

function getToutesLesSeries() {
    $pdo = connexionBDD();
    $req = $pdo->query('
        SELECT s.num_serie,
               s.titre_serievf,
               s.titre_serievo,
               s.annee_creation,
               s.duree_episode,
               g.lib_genre,
               p.nom_pays,
               per.nom_pers    AS createur_nom,
               per.pnom_pers   AS createur_prenom
        FROM Serie s
        JOIN Genre    g   ON s.num_genre = g.num_genre
        JOIN Pays     p   ON s.num_pays  = p.num_pays
        JOIN Createur c   ON s.numero    = c.numero
        JOIN Personne per ON c.code_pers = per.code_pers
        ORDER BY s.titre_serievf
    ');
    return $req->fetchAll();
}

function getInfoSerie($numSerie) {
    $pdo = connexionBDD();
    $req = $pdo->prepare('
        SELECT s.num_serie,
               s.titre_serievf,
               s.titre_serievo,
               s.annee_creation,
               s.duree_episode,
               s.musique,
               s.resume,
               g.lib_genre,
               p.nom_pays,
               per.nom_pers  AS createur_nom,
               per.pnom_pers AS createur_prenom,
               COUNT(DISTINCT sa.num_saison) AS nb_saisons,
               STRING_AGG(DISTINCT CASE WHEN ch.pays_chaine = \'France\'      THEN ch.lib_chaine END, \', \') AS chaines_france,
               STRING_AGG(DISTINCT CASE WHEN ch.pays_chaine = \'Etats-Unis\'  THEN ch.lib_chaine END, \', \') AS chaines_us
        FROM Serie s
        JOIN Genre    g   ON s.num_genre  = g.num_genre
        JOIN Pays     p   ON s.num_pays   = p.num_pays
        JOIN Createur c   ON s.numero     = c.numero
        JOIN Personne per ON c.code_pers  = per.code_pers
        LEFT JOIN Saison   sa ON s.num_serie  = sa.num_serie
        LEFT JOIN Diffuser d  ON s.num_serie  = d.num_serie
        LEFT JOIN Chaine   ch ON d.num_chaine = ch.num_chaine
        WHERE s.num_serie = :num_serie
        GROUP BY s.num_serie, s.titre_serievf, s.titre_serievo,
                 s.annee_creation, s.duree_episode, s.musique, s.resume,
                 g.lib_genre, p.nom_pays, per.nom_pers, per.pnom_pers
    ');
    $req->execute([':num_serie' => $numSerie]);
    return $req->fetch();
}
