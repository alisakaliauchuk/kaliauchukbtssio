<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($serie['titre_serievf']); ?> – Saison <?php echo intval($numSaison); ?> – SérieSite</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header>
    <a href="serieController.php" class="logo">🎬 SérieSite</a>
    <nav>
        <a href="serieController.php">Catalogue</a>
        <a href="logout.php">Déconnexion</a>
    </nav>
</header>

<div class="contenu">

    <p class="fil-ariane">
        <a href="serieController.php">Catalogue</a> &rsaquo;
        <a href="infoSerieController.php?num_serie=<?php echo intval($serie['num_serie']); ?>">
            <?php echo htmlspecialchars($serie['titre_serievf']); ?>
        </a> &rsaquo;
        Saison <?php echo intval($numSaison); ?>
    </p>

    <!-- Liste déroulante sélecteur de saison -->
    <div class="selecteur-saison">
        <label for="choix-saison">SAISON <?php echo intval($numSaison); ?></label>
        <select id="choix-saison"
                onchange="window.location='saisonController.php?num_serie=<?php echo intval($serie['num_serie']); ?>&num_saison='+this.value">
            <?php foreach ($saisons as $s) : ?>
                <option value="<?php echo intval($s['num_saison']); ?>"
                    <?php if (intval($s['num_saison']) === $numSaison) echo 'selected'; ?>>
                    Saison <?php echo intval($s['num_saison']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <!-- Titre centré en bleu -->
    <div class="titre-saison-page">
        <?php echo htmlspecialchars($serie['titre_serievf']); ?> Saison <?php echo intval($numSaison); ?>
    </div>

    <!-- Bloc info saison : image à gauche + tableau à droite -->
    <?php if ($saisonCourante !== null) : ?>
    <div class="bloc-saison">

        <img src="../assets/images/saison_<?php echo intval($serie['num_serie']); ?>_<?php echo intval($numSaison); ?>.jpg"
             onerror="this.src='../assets/images/default.jpg'"
             alt="Saison <?php echo intval($numSaison); ?>">

        <table class="table-saison">
            <?php if (!empty($producteurs)) : ?>
            <tr>
                <td>Producteur(s) exécutif(s) :</td>
                <td>
                    <?php
                    $noms = [];
                    foreach ($producteurs as $prod) {
                        $noms[] = htmlspecialchars($prod['producteur']);
                    }
                    echo implode(', ', $noms);
                    ?>
                </td>
            </tr>
            <?php endif; ?>
            <tr>
                <td>Nombre d'épisodes :</td>
                <td><?php echo count($episodes); ?></td>
            </tr>
            <?php if (!empty($saisonCourante['date_debut_tournage'])) : ?>
            <tr>
                <td>Date de Début de Tournage :</td>
                <td><?php echo htmlspecialchars($saisonCourante['date_debut_tournage']); ?></td>
            </tr>
            <?php endif; ?>
            <?php if (!empty($saisonCourante['date_fin_tournage'])) : ?>
            <tr>
                <td>Date de fin de tournage :</td>
                <td><?php echo htmlspecialchars($saisonCourante['date_fin_tournage']); ?></td>
            </tr>
            <?php endif; ?>
        </table>
    </div>
    <?php endif; ?>

    <!-- Liste des épisodes -->
    <?php if (empty($episodes)) : ?>
        <p class="vide">Aucun épisode disponible pour cette saison.</p>
    <?php else : ?>
        <div class="liste-episodes">
            <?php foreach ($episodes as $ep) : ?>
            <!-- Clic sur l'image de l'épisode → lecteur vidéo -->
            <a href="episodeController.php?num_serie=<?php echo intval($ep['num_serie']); ?>&num_saison=<?php echo intval($ep['num_saison']); ?>&num_epi=<?php echo intval($ep['num_epi']); ?>"
               class="carte-episode">

                <!-- Image de l'épisode -->
                <div class="vignette-ep">🎬</div>

                <!-- Infos de l'épisode -->
                <div>
                    <div class="ep-titre">
                        Episode <?php echo intval($ep['num_saison']); ?>x<?php echo str_pad(intval($ep['num_epi']), 2, '0', STR_PAD_LEFT); ?> :
                        <?php echo htmlspecialchars($ep['titre_vo']); ?>
                    </div>
                    <?php if (!empty($ep['titre_vf']) && $ep['titre_vf'] !== $ep['titre_vo']) : ?>
                        <div class="ep-titre-vf"><?php echo htmlspecialchars($ep['titre_vf']); ?></div>
                    <?php endif; ?>
                    <?php if (!empty($ep['resume_epi'])) : ?>
                        <div class="ep-resume">
                            <?php
                            $resume = htmlspecialchars($ep['resume_epi']);
                            // Afficher les 160 premiers caractères avec "..."
                            echo mb_strlen($resume) > 160 ? mb_substr($resume, 0, 160) . '...' : $resume;
                            ?>
                        </div>
                    <?php endif; ?>
                </div>

            </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</div>

</body>
</html>
