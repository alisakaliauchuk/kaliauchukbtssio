<?php
require_once __DIR__ . '/Database.php';

class QuaiModel {

    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function getQuaisPostes(): array {
        $stmt = $this->db->query('SELECT * FROM "Liste_quais_postes" ORDER BY "NumQuai", "NumPoste"');
        return $stmt->fetchAll();
    }

    public function getQuaisFret(): array {
        $stmt = $this->db->query('SELECT * FROM "Liste_quais_typeFret" ORDER BY "NumQuai"');
        return $stmt->fetchAll();
    }
}
