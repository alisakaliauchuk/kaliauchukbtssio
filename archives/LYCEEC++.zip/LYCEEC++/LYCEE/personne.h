#ifndef PERSONNE_H
#define PERSONNE_H

#include <iostream>
#include <string>

using namespace std ;

class personne
{
    private:
        char sexe;

    public :
        string nom;
        string prenom;

        /*constructeurs*/
        personne();
        personne(string nom);
        personne(string nom, char sexe);
        personne(string nom, string prenom, char sexe);

        /*destructeur*/
        ~personne();

        /*prototype des autres méthodes public*/
        void afficher();
        bool verifSexe(char val);

    protected:
        void setSexe(char s);
        char getSexe(); // c'est pour les titres
};

void affichePersonne(personne* tab, int taille);
bool controlPersonne(personne* tab, int& taille, string nomSaisi, int N);
void saisiePersonne(personne* tab, int& taille, int N);

#endif ;
