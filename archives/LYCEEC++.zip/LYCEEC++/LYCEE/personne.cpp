#include "personne.h"

    personne::personne()
    {
        cout<<"création d'une personne "<< endl ;
    }

    personne::personne(string nom)
    {
        this->nom = nom ;
        this->sexe = '\0';
        cout<<"création d'une personne avec arguments "<< endl ;
    }

    personne::personne(string nom, char sexe)
    {
        this->nom = nom ;

        if (sexe == 'F'||sexe == 'H')
            this->sexe = sexe;
        else
            this->sexe = '\0';
        cout<<"création d'une personne avec nom et sexe "<< endl ;
    }

    personne::personne(string nom, string prenom, char sexe)
    {
        this->nom = nom;
        this->prenom = prenom;
        if (sexe == 'F' || sexe == 'H')
            this->sexe = sexe;
        else
            this->sexe = '\0';
        cout << "création d'une personne avec nom, prenom et sexe " << endl;
    }

    personne::~personne()
    {
        cout<<"destruction de la personne "<< endl ;
    }

    void personne::afficher()
    {
        cout << "la personne s'appelle " << this->nom << endl;
        if (this->sexe == 'F')
            cout << "cette personne est une femme" << endl;
        else if (this->sexe == 'H')
            cout << "cette personne est un homme" << endl;
    }

    void affichePersonne(personne* tab, int taille)
    {
        cout << "\nContenu du tableau" << endl;
        for (int i = 0; i < taille; i++)
        {
            tab[i].afficher();
        }
    }

    bool controlPersonne(personne* tab, int& taille, string nomSaisi, int N)
    {
        for (int i = 0; i < taille; i++)
        {
            if (tab[i].nom == nomSaisi)
            {
                cout << "Erreur:" << nomSaisi << " est déjà dans tableau." << endl;
                return false;
            }
        }
        if (taille >= N)
        {
            cout << "Erreur: tableau est plein." << endl;
            return false;
        }
        tab[taille] = personne(nomSaisi);
        taille++;
        return true;
    }

    void saisiePersonne(personne* tab, int& taille, int N)
    {
        cout << "\n Voici le contenu actuel du table tabD" << endl;
        affichePersonne(tab, taille);

        string nomSaisi;
        while (taille < N)
        {
            cout << "Saisissez les noms de personnes (FIN pour arrêter)" << endl;
            cin >> nomSaisi;

            if (nomSaisi == "FIN")
            {
                cout << "Arrêt de la saisie." << endl;
                break;
            }
            controlPersonne(tab, taille, nomSaisi, N);
        }
        if (taille >= N)
        {
            cout << "Tableau plein, fin de saisie." << endl;
        }
    }

    void personne::setSexe(char s)
    {
        this->sexe = s;
    }

    // pour mttre des titres (étudiante ou étudiant)
    char personne::getSexe()
    {
        return this->sexe;
    }

    bool personne::verifSexe(char val)
    {
        return this->sexe == val;
    }
