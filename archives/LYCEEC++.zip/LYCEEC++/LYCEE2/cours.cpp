#include "cours.h"

cours::cours(string intitule)
{
    this->intitule = intitule;
    this->enseignantDuCours = nullptr;
}
