#include "ville.h"

ville::ville(string nom, string cp)
{
    this->nom = nom;
    this->cp = cp;
}
