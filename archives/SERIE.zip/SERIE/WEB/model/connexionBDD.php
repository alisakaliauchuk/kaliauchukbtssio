<?php

function connexionBDD() {
    $hote = 'localhost';
    $bdd  = 'serie';
    $user = 'postgres';
    $mdp  = '1234';

    try {
        $pdo = new PDO("pgsql:host=$hote;dbname=$bdd", $user, $mdp);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $pdo;
    } catch (PDOException $e) {
        die("Erreur de connexion : " . $e->getMessage());
    }
}
