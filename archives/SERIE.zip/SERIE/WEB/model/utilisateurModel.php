<?php

require_once 'connexionBDD.php';

function utilisateurExiste($identifiant) {
    $pdo = connexionBDD();
    $req = $pdo->prepare('SELECT COUNT(*) AS nb FROM Utilisateur WHERE identifiant = :identifiant');
    $req->execute([':identifiant' => $identifiant]);
    $res = $req->fetch();
    return $res['nb'] > 0;
}

function inscrireEtape1($identifiant, $motDePasse) {
    if (utilisateurExiste($identifiant)) {
        return false;
    }
    $pdo  = connexionBDD();
    $hash = password_hash($motDePasse, PASSWORD_BCRYPT);
    $req  = $pdo->prepare('INSERT INTO Utilisateur (identifiant, mot_de_passe) VALUES (:identifiant, :mot_de_passe)');
    return $req->execute([':identifiant' => $identifiant, ':mot_de_passe' => $hash]);
}

function inscrireEtape2($identifiant, $nom, $prenom, $adresse, $cp, $ville, $tel, $numCarte, $dateExp, $cvv) {
    $pdo = connexionBDD();
    $req = $pdo->prepare('UPDATE Utilisateur SET nom=:nom, prenom=:prenom, adresse=:adresse, cp=:cp, ville=:ville, tel=:tel, num_carte=:num_carte, date_exp=:date_exp, cvv=:cvv WHERE identifiant=:identifiant');
    return $req->execute([':nom' => $nom, ':prenom' => $prenom, ':adresse' => $adresse, ':cp' => $cp, ':ville' => $ville, ':tel' => $tel, ':num_carte' => $numCarte, ':date_exp' => $dateExp, ':cvv' => $cvv, ':identifiant' => $identifiant]);
}

function verifierConnexion($identifiant, $motDePasse) {
    $pdo = connexionBDD();
    $req = $pdo->prepare('SELECT mot_de_passe FROM Utilisateur WHERE identifiant = :identifiant');
    $req->execute([':identifiant' => $identifiant]);
    $res = $req->fetch();
    if (!$res) return false;
    return password_verify($motDePasse, $res['mot_de_passe']);
}
