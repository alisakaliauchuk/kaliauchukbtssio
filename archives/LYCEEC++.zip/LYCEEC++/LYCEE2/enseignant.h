#ifndef ENSEIGNANT_H
#define ENSEIGNANT_H
#include "../LYCEE/personne.h"
#include "ville.h"

class enseignant : public personne
{
private:
    float salaire;
    ville* maVille;

public:
    string matiere;
    enseignant(string nom, string matiere, char sexe, float salaire, ville* v);
    void afficher();
    void setSexe(char s);
    string getNom();
    string getMatiere();
};
#endif
