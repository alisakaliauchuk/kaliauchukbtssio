// Partie A
#include <QCoreApplication>
#include <QtSql> // module Qt pour les bases de données
#include <QDebug> // module Qt pour afficher des messages dans la console

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    // crée un objet de connexion en utilisant le driver PostgreSQL (QPSQL)
    QSqlDatabase db = QSqlDatabase::addDatabase("QPSQL");
    // adresse du serveur de base de données
    db.setHostName("localhost");
    // nom de la base de données à laquelle on se connecte
    db.setDatabaseName("LYCEE");
    // nom d'util PostgreSQL
    db.setUserName("postgres");
    // mdp PostgreSQL
    db.setPassword("postgres");

    // tentative d'ouverture de la connexion, affiche une erreur si échec
    if (!db.open()) {
        qDebug() << "Erreur connexion :" << db.lastError().text();
        return -1;
    }
    // affiche message de connexion réussie
    qDebug() << "Connexion réussie !";
    //db.close(); // ferme la session

    // Partie B
    // crée un objet requête lié à la connexion active
    QSqlQuery query;

    // exécute la requête SQL pour récupérer id et nom de table personne
    query.exec("SELECT id, nom FROM personne");

    // parcourt les résultat ligne par ligne
    while (query.next()) {
        // recupère la valeur de colonne id et la convertit en entier
        int id = query.value(0).toInt();
        // recupère ma vameur de colonne nom et la convertit en entier
        QString nom = query.value(1).toString();
        // affiche l'id et le nom dans console
        qDebug() << id << nom;
    }

    // Partie C
    // prépare une requête avec un paramètre nommé :nom (plus sécurisé)
    query.prepare("SELECT id, nom FROM personne WHERE nom = :nom");

    // associe la valeur "Kaliauchuk" au paramètre :nom
    query.bindValue(":nom", "Kaliauchuk");

    // exécute la requête préparée, affiche une erreur si échec
    if (!query.exec()) {
        qDebug() << "Erreur SELECT :" << query.lastError().text();
    }

    // parcourt les résultats de la requête préparée
    while (query.next()) {
        int id = query.value(0).toInt();
        QString nom = query.value(1).toString();
        qDebug() << id << nom;
    }

    db.close(); // ferme la session
    return a.exec();
}
