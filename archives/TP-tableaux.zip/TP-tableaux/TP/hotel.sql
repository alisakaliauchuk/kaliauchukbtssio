\c postgres
DROP DATABASE IF EXISTS hotel;

CREATE DATABASE hotel;
\c hotel


CREATE TABLE reservation (
    id SERIAL,
    nom VARCHAR(50),
    prenom VARCHAR(50),
    adresse VARCHAR(200),
    numero_tel VARCHAR(14),
    ville VARCHAR(200),
    num_chambre INT,

    PRIMARY KEY (id)
);


CREATE TABLE date_reservation (
    id SERIAL,
    date VARCHAR,
    client_id INT,
    chambre_id INT,

    PRIMARY KEY (id)
);
CREATE USER squirrel LOGIN PASSWORD 'slam';

GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE reservation, date_reservation TO squirrel;
