CREATE TABLE client(
   id_client INT,
   nom VARCHAR(100) NOT NULL,
   adresse VARCHAR(200),
   cp CHAR(5),
   ville VARCHAR(50),
   tel VARCHAR(13),
   PRIMARY KEY(id_client)
);

CREATE TABLE cartouche(
   reference CHAR(5),
   designation VARCHAR(150),
   PRIMARY KEY(reference)
);

CREATE TABLE cartouche_typee(
   reference CHAR(5),
   type CHAR(1),
   tarif DECIMAL(9,2) CHECK (tarif > 0),
   PRIMARY KEY(reference, type),
   FOREIGN KEY(reference) REFERENCES cartouche(reference)
);


CREATE TABLE client_regulier(
   id_client INT,
   nom_contact VARCHAR(50) NOT NULL,
   PRIMARY KEY(id_client),
   FOREIGN KEY(id_client) REFERENCES client(id_client)
);

CREATE TABLE client_occasionnel(
   id_client INT,
   PRIMARY KEY(id_client),
   FOREIGN KEY(id_client) REFERENCES client(id_client)
);

CREATE TABLE facture(
   id_facture INT,
   date_facture DATE,
   id_client INT NOT NULL,
   PRIMARY KEY(id_facture),
   FOREIGN KEY(id_client) REFERENCES client(id_client)
);

CREATE TABLE avoir(
   id_avoir INT,
   date_avoir DATE,
   id_facture INT NOT NULL,
   PRIMARY KEY(id_avoir),
   FOREIGN KEY(id_facture) REFERENCES facture(id_facture)
);

CREATE TABLE contrat(
   id_contrat INT,
   date_contrat DATE,
   duree INT CHECK (duree IN (60, 90)),
   id_client INT NOT NULL,
   PRIMARY KEY(id_contrat),
   FOREIGN KEY(id_client) REFERENCES client_regulier(id_client)
);

CREATE TABLE concerner(
   reference CHAR(5),
   type CHAR(1),
   id_contrat INT,
   quantite_mini INT CHECK (quantite_mini > 0 AND quantite_mini <= 1000),
   tarif DECIMAL(9,2) CHECK (tarif > 0),
   PRIMARY KEY(reference, type, id_contrat),
   FOREIGN KEY(reference, type) REFERENCES cartouche_typee(reference, type),
   FOREIGN KEY(id_contrat) REFERENCES contrat(id_contrat)
);

CREATE TABLE facturer(
   reference CHAR(5),
   type CHAR(1),
   id_facture INT,
   quantite INT CHECK (quantite > 0 AND quantite <= 1000),
   PRIMARY KEY(reference, type, id_facture),
   FOREIGN KEY(reference, type) REFERENCES cartouche_typee(reference, type),
   FOREIGN KEY(id_facture) REFERENCES facture(id_facture)
);

CREATE TABLE deduire(
   id_facture INT,
   id_avoir INT,
   PRIMARY KEY(id_facture, id_avoir),
   FOREIGN KEY(id_facture) REFERENCES facture(id_facture),
   FOREIGN KEY(id_avoir) REFERENCES avoir(id_avoir)
);


CREATE OR REPLACE FUNCTION DetermineTarifFacture(
   p_id_client INT,
   p_reference CHAR(5),
   p_type CHAR(1),
   p_quantite INT
)
RETURNS DECIMAL (9,2)
AS $$
DECLARE
   v_tarif_normal DECIMAL(9,2);
   v_tarif_negocie DECIMAL(9,2);
   v_quantite_mini INT;
BEGIN
   SELECT tarif INTO v_tarif_normal
   FROM cartouche_typee
   WHERE reference = p_reference
   AND type = p_type;

   SELECT c.quantite_mini, c.tarif
   INTO v_quantite_mini, v_tarif_negocie
   FROM concerner c JOIN contrat ct ON ct.id_contrat = c.id_contrat
   WHERE ct.id_client = p_id_client
   AND c.reference = p_reference
   AND c.type = p_type
   ORDER BY c.quantite_mini DESC
   LIMIT 1;

   IF v_quantite_mini IS NULL THEN
      RETURN v_tarif_normal;
   END IF;

   IF p_quantite >= v_quantite_mini THEN
      RETURN v_tarif_negocie;
   ELSE
      RETURN v_tarif_normal;
   END IF;
END;
$$ LANGUAGE plpgsql;



SELECT fa.date_facture, f.reference, c.designation, f.type, f.quantite AS quantite_factureee, DetermineTarifFacture(fa.id_client, f.reference, f.type, f.quantite) AS tarif_facture, cn.quantite_mini AS quantite_negociee, cn.tarif AS tarif_negocie, (f.quantite * DetermineTarifFacture(fa.id_client, f.reference, f.type, f.quantite)) AS total_ligne_ht
FROM facturer f JOIN facture fa ON f.id_facture = fa.id_facture
               JOIN cartouche_typee ct ON f.reference = ct.reference 
                  AND f.type = ct.type
               JOIN cartouche c ON c.reference = f.reference
               JOIN concerner cn ON cn.reference = f.reference 
                  AND cn.type = f.type
WHERE f.reference = 'B204'
   AND f.type = 'N'
   AND fa.id_client = 3
ORDER BY fa.date_facture;

CREATE OR REPLACE VIEW vue_detail_facture 
AS
SELECT f.id_facture, f.reference, c.designation, c.image, f.type, f.quantite, DetermineTarifFacture(fa.id_client, f.reference, f.type, f.quantite) AS tarif_facture, (f.quantite * DetermineTarifFacture(fa.id_client, f.reference, f.type, f.quantite)) AS montant_ht
FROM facturer f JOIN facture fa ON f.id_facture = fa.id_facture
JOIN cartouche_typee ct ON f.reference = ct.reference AND f.type = ct.type
JOIN cartouche c ON ct.reference = c.reference
ORDER BY f.reference;




ALTER TABLE cartouche SET COLUMN image VARCHAR(200);