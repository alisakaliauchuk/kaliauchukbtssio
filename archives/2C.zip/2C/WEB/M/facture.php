<?php

class Facture {

    public static float $TVA = 0.20;
    
    private int $id;
    private string $date;
    private Client $client;

    public function __construct(int $id, string $date, Client $client) {
        $this->id = $id;
        $this->date = $date;
        $this->client = $client;
    }

    public function getId(): int { return $this->id; }
    public function getDate(): string { return $this->date; }
    public function getClient(): Client { return $this->client; }
}
?>
