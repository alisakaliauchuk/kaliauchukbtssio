<?php require __DIR__ . '/../layout/header.php'; ?>

<div class="page-header">
    <h1>🚢 Liste des Navires</h1>

    <!-- Barre de recherche -->
    <form method="GET" action="/index.php" class="search-form">
        <input type="hidden" name="page" value="navires">
        <input
            type="text"
            name="search"
            placeholder="Rechercher un navire..."
            value="<?= htmlspecialchars($search ?? '') ?>"
            class="search-input"
        >
        <button type="submit" class="btn btn-primary">Rechercher</button>
        <?php if (!empty($search)): ?>
            <a href="/index.php?page=navires" class="btn btn-secondary">Réinitialiser</a>
        <?php endif; ?>
    </form>
</div>

<?php if (empty($navires)): ?>
    <div class="alert alert-info">Aucun navire trouvé.</div>
<?php else: ?>

<div class="table-wrapper">
    <table class="data-table">
        <thead>
            <tr>
                <th>N° Lloyd's</th>
                <th>Nom du navire</th>
                <th>Type</th>
                <th>Pavillon</th>
                <th>Largeur (m)</th>
                <th>Longueur (m)</th>
                <th>Tirant d'eau</th>
                <th>Capacité (m³)</th>
                <th>Armateur</th>
                <th>Propulsé</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($navires as $n): ?>
            <tr>
                <td><?= htmlspecialchars($n['nolloyds']) ?></td>
                <td class="navire-nom"><?= htmlspecialchars($n['nomnavire']) ?></td>
                <td><?= htmlspecialchars($n['typenavire'] ?? '—') ?></td>
                <td><?= htmlspecialchars($n['pavillon'] ?? '—') ?></td>
                <td><?= htmlspecialchars($n['largeur'] ?? '—') ?></td>
                <td><?= htmlspecialchars($n['longueur'] ?? '—') ?></td>
                <td><?= htmlspecialchars($n['tirantdeau'] ?? '—') ?></td>
                <td><?= htmlspecialchars($n['capacite'] ?? '—') ?></td>
                <td><?= htmlspecialchars($n['nomarmateur'] ?? '—') ?></td>
                <td class="propulse">
                    <?= $n['propulse'] 
                        ? '<span class="badge badge-yes">O</span>' 
                        : '<span class="badge badge-no">N</span>' ?>
                </td>
                <td>
                    <a href="index.php?page=navires&action=detail&id=<?= $n['nolloyds'] ?>"
                    class="btn btn-escale">Détail</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<p class="table-count"><?= count($navires) ?> navire(s) affiché(s)</p>

<?php endif; ?>

<?php require __DIR__ . '/../layout/footer.php'; ?>
