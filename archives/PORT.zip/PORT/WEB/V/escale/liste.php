<?php require __DIR__ . '/../layout/header.php'; ?>

<div class="page-header">
    <h1>⚓ Toutes les Escales</h1>
</div>

<?php if (empty($escales)): ?>
    <div class="alert alert-info">Aucune escale enregistrée.</div>
<?php else: ?>

<div class="table-wrapper">
    <table class="data-table">
        <thead>
            <tr>
                <th>N° Escale</th>
                <th>Navire</th>
                <th>Arrivée</th>
                <th>Départ</th>
                <th>Provenance</th>
                <th>Destination</th>
                <th>Imp/Exp</th>
                <th>Quai</th>
                <th>Poste</th>
                <th>Tonnage</th>
                <th>Confirmée</th>
                <th>Fiche</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($escales as $e): ?>
            <tr>
                <td><?= htmlspecialchars($e['NumEscale']) ?></td>
                <td class="navire-nom">
                    <a href="/index.php?page=navires&action=detail&id=<?= $e['NoLloyds'] ?>">
                        <?= htmlspecialchars($e['NomNavire']) ?>
                    </a>
                </td>
                <td><?= htmlspecialchars($e['DateArrivee'] ?? '—') ?></td>
                <td><?= htmlspecialchars($e['DateDepart'] ?? '—') ?></td>
                <td><?= htmlspecialchars($e['Provenance'] ?? '—') ?></td>
                <td><?= htmlspecialchars($e['Destination'] ?? '—') ?></td>
                <td><?= htmlspecialchars($e['ImportExport'] ?? '—') ?></td>
                <td><?= htmlspecialchars($e['NomQuai'] ?? '—') ?></td>
                <td><?= htmlspecialchars($e['NumPoste'] ?? '—') ?></td>
                <td><?= htmlspecialchars($e['Tonnage'] ?? '—') ?></td>
                <td>
                    <?= $e['EscaleConfirmee']
                        ? '<span class="badge badge-yes">Oui</span>'
                        : '<span class="badge badge-no">Non</span>' ?>
                </td>
                <td>
                    <a href="/index.php?page=escales&action=detail&id=<?= $e['NumEscale'] ?>"
                       class="btn btn-escale">
                        escale
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<p class="table-count"><?= count($escales) ?> escale(s) affichée(s)</p>

<?php endif; ?>

<?php require __DIR__ . '/../layout/footer.php'; ?>
