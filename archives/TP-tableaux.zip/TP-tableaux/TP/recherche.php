<?php
header("Content-Type: text/html");
require_once('constantes.inc.php');

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['date'])) {
    echo json_encode(['success' => false, 'message' => 'Date non spécifiée']);
    exit;
}

$dateReservation = $data['date'];

try {
    $db = new PDO(DSN, UTILISATEUR, MDP);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $query = "
        SELECT c.num_chambre, 
               CASE WHEN r.date_reservation = :dateReservation THEN 'occupée' ELSE 'libre' END AS statut
        FROM chambres c
        LEFT JOIN reservation r ON c.num_chambre = r.num_chambre AND r.date_reservation = :dateReservation";

    $requete = $db->prepare($query);
    $requete->bindParam(':dateReservation', $dateReservation);
    $requete->execute();

    $chambres = $requete->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'chambres' => $chambres]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erreur : ' . $e->getMessage()]);
}

if (!isset($data['nom'], $data['prenom'], $data['adresse'], $data['numero_tel'], $data['ville'], $data['num_chambre'], $data['date'])) {
    echo json_encode(['success' => false, 'message' => 'Données manquantes']);
    exit;
}

try {
    $pdo = new PDO(DSN, UTILISATEUR, MDP);
    //$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // utile pour le débogage
} catch(PDOException $e) {
    echo "problème de connexion\n";
    echo $e->getMessage();
    exit(1); // on arrête le script
}
try{
    $query = "INSERT INTO reservation (nom, prenom, adresse, numero_tel, ville, num_chambre, date_reservation) 
              VALUES (:nom, :prenom, :adresse, :numero_tel, :ville, :num_chambre, :date)";
    $requete = $db->prepare($query);
    $requete->bindParam(':nom', $data['nom']);
    $requete->bindParam(':prenom', $data['prenom']);
    $requete->bindParam(':adresse', $data['adresse']);
    $requete->bindParam(':numero_tel', $data['numero_tel']);
    $requete->bindParam(':ville', $data['ville']);
    $requete->bindParam(':num_chambre', $data['num_chambre']);
    $requete->bindParam(':date', $data['date']);
    $requete->execute();

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erreur : ' . $e->getMessage()]);
}
?>
