<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Informations personnelles – Série Site</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="auth-page">
    <div class="auth-carte" style="max-width: 500px;">

        <h2>Série Site</h2>
        <p class="sous-titre">Informations personnelles – Étape 2 sur 2</p>

        <?php if ($erreur !== '') : ?>
            <div class="message-erreur"><?php echo htmlspecialchars($erreur); ?></div>
        <?php endif; ?>

        <form method="POST" action="index.php">
            <input type="hidden" name="action" value="inscription_etape2">

            <div class="form-groupe">
                <label for="nom">Nom *</label>
                <input type="text" id="nom" name="nom" value="<?php echo htmlspecialchars($_POST['nom'] ?? ''); ?>" required>
            </div>

            <div class="form-groupe">
                <label for="prenom">Prénom *</label>
                <input type="text" id="prenom" name="prenom" value="<?php echo htmlspecialchars($_POST['prenom'] ?? ''); ?>" required>
            </div>

            <div class="form-groupe">
                <label for="adresse">Adresse *</label>
                <input type="text" id="adresse" name="adresse" value="<?php echo htmlspecialchars($_POST['adresse'] ?? ''); ?>" required>
            </div>

            <div class="form-groupe">
                <label for="cp">Code postal *</label>
                <input type="text" id="cp" name="cp" value="<?php echo htmlspecialchars($_POST['cp'] ?? ''); ?>" required>
            </div>

            <div class="form-groupe">
                <label for="ville">Ville *</label>
                <input type="text" id="ville" name="ville" value="<?php echo htmlspecialchars($_POST['ville'] ?? ''); ?>" required>
            </div>

            <div class="form-groupe">
                <label for="tel">Téléphone</label>
                <input type="tel" id="tel" name="tel" placeholder="06 00 00 00 00" value="<?php echo htmlspecialchars($_POST['tel'] ?? ''); ?>">
            </div>

            <p style="font-size:12px; color:#888; margin: 15px 0 10px; text-transform:uppercase; letter-spacing:1px;">
                Carte bancaire
            </p>

            <div class="form-groupe">
                <label for="num_carte">Numéro de carte</label>
                <input type="text" id="num_carte" name="num_carte" placeholder="0000 0000 0000 0000" maxlength="19" value="<?php echo htmlspecialchars($_POST['num_carte'] ?? ''); ?>">
            </div>

            <div class="form-groupe">
                <label for="date_exp">Date d'expiration</label>
                <input type="text" id="date_exp" name="date_exp" placeholder="MM/AA" maxlength="5" value="<?php echo htmlspecialchars($_POST['date_exp'] ?? ''); ?>">
            </div>

            <div class="form-groupe">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv" placeholder="•••" maxlength="4" value="<?php echo htmlspecialchars($_POST['cvv'] ?? ''); ?>">
            </div>

            <button type="submit" class="btn-complet">Créer mon compte</button>
        </form>

    </div>
</div>

</body>
</html>
