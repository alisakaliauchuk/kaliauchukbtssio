<?php
session_start();

if (!isset($_SESSION['utilisateur'])) {
    header('Location: index.php');
    exit;
}

require_once '../model/episodeModel.php';
require_once '../model/serieModel.php';

$numSerie  = intval($_GET['num_serie']  ?? 0);
$numSaison = intval($_GET['num_saison'] ?? 0);
$numEpi    = intval($_GET['num_epi']    ?? 0);

if ($numSerie <= 0 || $numSaison <= 0 || $numEpi <= 0) {
    header('Location: serieController.php');
    exit;
}

$episode = getInfoEpisode($numSerie, $numSaison, $numEpi);
$serie   = getInfoSerie($numSerie);

if (!$episode) {
    header('Location: serieController.php');
    exit;
}

require '../vue/lecteurEpisode.php';
