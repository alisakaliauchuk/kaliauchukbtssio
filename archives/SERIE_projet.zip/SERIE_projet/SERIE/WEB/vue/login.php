<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion – Série Site</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="auth-page">
    <div class="auth-carte">

        <h2>🎬 Série Site</h2>
        <p class="sous-titre">Connectez-vous à votre compte</p>

        <?php if ($erreur !== '') : ?>
            <div class="message-erreur"><?php echo htmlspecialchars($erreur); ?></div>
        <?php endif; ?>

        <form method="POST" action="index.php">
            <input type="hidden" name="action" value="login">

            <div class="form-groupe">
                <label for="identifiant">Adresse e-mail</label>
                <input type="email" id="identifiant" name="identifiant" placeholder="exemple@mail.com" value="<?php echo htmlspecialchars($_POST['identifiant'] ?? ''); ?>" required>
            </div>

            <div class="form-groupe">
                <label for="mot_de_passe">Mot de passe</label>
                <input type="password" id="mot_de_passe" name="mot_de_passe" placeholder="••••••••" required>
            </div>

            <button type="submit" class="btn-complet">S'identifier</button>
        </form>

        <form method="GET" action="index.php">
            <input type="hidden" name="action" value="inscription">
            <button type="submit" class="btn-complet secondaire">Créer un compte</button>
        </form>

    </div>
</div>

</body>
</html>
