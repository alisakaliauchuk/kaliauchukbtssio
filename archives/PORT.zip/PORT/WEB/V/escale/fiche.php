<?php require __DIR__ . '/../layout/header.php'; ?>

<div class="page-header">
    <a href="javascript:history.back()" class="btn btn-secondary">← Retour</a>
    <h1>⚓ Fiche Escale n°<?= htmlspecialchars($escale['numescale']) ?></h1>
</div>

<div class="fiche-escale-wrapper">

    <!-- NAVIRE -->
    <div class="fiche-bloc">
        <div class="fiche-bloc-title">NAVIRE</div>
        <div class="fiche-bloc-body">
            <div class="fiche-nav-img">🚢</div>
            <div class="fiche-grid">
                <div class="fiche-row">
                    <span class="fiche-label">Longueur</span>
                    <span class="fiche-value"><?= htmlspecialchars($escale['longueur'] ?? '—') ?></span>
                </div>
                <div class="fiche-row">
                    <span class="fiche-label">Nom</span>
                    <span class="fiche-value"><?= htmlspecialchars($escale['nomnavire'] ?? '—') ?></span>
                </div>
                <div class="fiche-row">
                    <span class="fiche-label">Largeur</span>
                    <span class="fiche-value"><?= htmlspecialchars($escale['largeur'] ?? '—') ?></span>
                </div>
                <div class="fiche-row">
                    <span class="fiche-label">Propulseur</span>
                    <span class="fiche-value">
                        <?= $escale['propulseur']
                            ? '<label><input type="radio" checked disabled> Oui</label>'
                            : '<label><input type="radio" checked disabled> Non</label>' ?>
                    </span>
                </div>
                <div class="fiche-row">
                    <span class="fiche-label">Tirant d'eau</span>
                    <span class="fiche-value"><?= htmlspecialchars($escale['tirantdeau'] ?? '—') ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- ENTRÉE / SORTIE -->
    <div class="fiche-bloc">
        <div class="fiche-bloc-title">ENTRÉE</div>
        <div class="fiche-bloc-body">
            <div class="fiche-grid">
                <div class="fiche-row">
                    <span class="fiche-label">Nom Pilote</span>
                    <span class="fiche-value"><?= htmlspecialchars($escale['piloteentree'] ?? '—') ?></span>
                </div>
            </div>
        </div>

        <div class="fiche-bloc-title" style="margin-top:1rem">SORTIE</div>
        <div class="fiche-bloc-body">
            <div class="fiche-grid">
                <div class="fiche-row">
                    <span class="fiche-label">Nom Pilote</span>
                    <span class="fiche-value"><?= htmlspecialchars($escale['pilotesortie'] ?? '—') ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- ESCALE -->
    <div class="fiche-bloc fiche-bloc-full">
        <div class="fiche-bloc-title">ESCALE</div>
        <div class="fiche-bloc-body fiche-escale-cols">

            <div class="fiche-col">
                <div class="fiche-row">
                    <span class="fiche-label">Agent</span>
                    <span class="fiche-value"><?= htmlspecialchars($escale['agent'] ?? '—') ?></span>
                </div>
                <div class="fiche-row">
                    <span class="fiche-label">Arrivée</span>
                    <span class="fiche-value">
                        <?= !empty($escale['datearrivee'])
                            ? date('d / m / Y', strtotime($escale['datearrivee']))
                            : '—' ?>
                    </span>
                </div>
                <div class="fiche-row">
                    <span class="fiche-label">Durée</span>
                    <span class="fiche-value">
                        <?php
                        $duree = '—';
                        if (!empty($escale['datearrivee']) && !empty($escale['datedepart'])) {
                            $diff  = (new DateTime($escale['datearrivee']))->diff(new DateTime($escale['datedepart']));
                            $duree = $diff->days . ' jour(s)';
                        }
                        echo $duree;
                        ?>
                    </span>
                </div>
                <div class="fiche-row">
                    <span class="fiche-label">Quai</span>
                    <span class="fiche-value"><?= htmlspecialchars($escale['nomquai'] ?? '—') ?></span>
                </div>
                <div class="fiche-row">
                    <span class="fiche-label">Poste</span>
                    <span class="fiche-value"><?= htmlspecialchars($escale['numposte'] ?? '—') ?></span>
                </div>
                <div class="fiche-row">
                    <span class="fiche-label">Import / Export</span>
                    <span class="fiche-value">
                        <label>
                            <input type="radio" <?= ($escale['importexport'] ?? '') === 'Export' ? 'checked' : '' ?> disabled>
                            Exportation
                        </label>
                        &nbsp;
                        <label>
                            <input type="radio" <?= ($escale['importexport'] ?? '') === 'Import' ? 'checked' : '' ?> disabled>
                            Importation
                        </label>
                    </span>
                </div>
                <div class="fiche-row">
                    <span class="fiche-label">Remorqueur</span>
                    <span class="fiche-value">
                        <label><input type="radio" disabled> Oui</label>
                        &nbsp;
                        <label><input type="radio" checked disabled> Non</label>
                    </span>
                </div>
            </div>

            <div class="fiche-col">
                <div class="fiche-row">
                    <span class="fiche-label">Provenance</span>
                    <span class="fiche-value"><?= htmlspecialchars($escale['provenance'] ?? '—') ?></span>
                </div>
                <div class="fiche-row">
                    <span class="fiche-label">Destination</span>
                    <span class="fiche-value"><?= htmlspecialchars($escale['destination'] ?? '—') ?></span>
                </div>
                <div class="fiche-row">
                    <span class="fiche-label">Manutentionnaire</span>
                    <span class="fiche-value">—</span>
                </div>
                <div class="fiche-row">
                    <span class="fiche-label">Escale confirmée</span>
                    <span class="fiche-value">
                        <label>
                            <input type="radio" <?= !empty($escale['escaleconfirmee']) ? 'checked' : '' ?> disabled>
                            Oui
                        </label>
                        &nbsp;
                        <label>
                            <input type="radio" <?= empty($escale['escaleconfirmee']) ? 'checked' : '' ?> disabled>
                            Non
                        </label>
                    </span>
                </div>
                <div class="fiche-row">
                    <span class="fiche-label">Matières Dangereuses</span>
                    <span class="fiche-value">
                        <label>
                            <input type="radio" <?= !empty($escale['matieredangereuse']) ? 'checked' : '' ?> disabled>
                            Oui
                        </label>
                        &nbsp;
                        <label>
                            <input type="radio" <?= empty($escale['matieredangereuse']) ? 'checked' : '' ?> disabled>
                            Non
                        </label>
                    </span>
                </div>
            </div>

        </div>
    </div>

    <!-- TYPE DE FRET -->
    <div class="fiche-bloc fiche-bloc-full">
        <div class="fiche-bloc-title">TYPE DE FRET</div>
        <div class="fiche-bloc-body">
            <div class="fiche-grid fiche-grid-row">
                <div class="fiche-row">
                    <span class="fiche-label">Nom</span>
                    <span class="fiche-value"><?= htmlspecialchars($escale['libelletypefret'] ?? '—') ?></span>
                </div>
                <div class="fiche-row">
                    <span class="fiche-label">Tonnage</span>
                    <span class="fiche-value"><?= htmlspecialchars($escale['tonnage'] ?? '—') ?></span>
                </div>
                <div class="fiche-row">
                    <span class="fiche-label">Quantité</span>
                    <span class="fiche-value"><?= htmlspecialchars($escale['qtefret'] ?? '—') ?></span>
                </div>
            </div>
        </div>
    </div>

</div>

<?php require __DIR__ . '/../layout/footer.php'; ?>