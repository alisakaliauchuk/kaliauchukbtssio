INSERT INTO LYCEE.PERSONNE (id, nom, prenom, sexe) VALUES (1, 'Gougelet', 'Estelle', 'F');
INSERT INTO LYCEE.PERSONNE (id, nom, prenom, sexe) VALUES (2, 'Kaliauchuk', 'Alisa','F');
INSERT INTO LYCEE.PERSONNE (id, nom, prenom, sexe) VALUES (3, 'Martin', 'Lucas', 'H');
INSERT INTO LYCEE.PERSONNE (id, nom, prenom, sexe) VALUES (4, 'Dupont', 'Alice', 'F');