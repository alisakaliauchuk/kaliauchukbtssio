<?php
session_start();

if (!isset($_SESSION['utilisateur'])) {
    header('Location: index.php');
    exit;
}

require_once '../model/serieModel.php';
require_once '../model/saisonModel.php';

$numSerie  = intval($_GET['num_serie']  ?? 0);
$numSaison = intval($_GET['num_saison'] ?? 1);

if ($numSerie <= 0) {
    header('Location: serieController.php');
    exit;
}

$serie    = getInfoSerie($numSerie);
$saisons  = getSaisonsDeSerie($numSerie);
$episodes = getEpisodesDeSaison($numSerie, $numSaison);

$saisonCourante = null;
foreach ($saisons as $s) {
    if (intval($s['num_saison']) === $numSaison) {
        $saisonCourante = $s;
        break;
    }
}

if ($saisonCourante === null && count($saisons) > 0) {
    $saisonCourante = $saisons[0];
    $numSaison      = intval($saisonCourante['num_saison']);
    $episodes       = getEpisodesDeSaison($numSerie, $numSaison);
}

require '../vue/saisonsSerie.php';
