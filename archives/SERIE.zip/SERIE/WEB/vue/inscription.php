<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Créer un compte – SérieSite</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="auth-page">
    <div class="auth-carte">
        <h2>🎬 SérieSite</h2>
        <p class="sous-titre">Créez votre compte – Étape 1 sur 2</p>

        <?php if ($erreur !== '') : ?>
            <div class="message-erreur"><?php echo htmlspecialchars($erreur); ?></div>
        <?php endif; ?>

        <form method="POST" action="index.php">
            <input type="hidden" name="action" value="inscription_etape1">
            <div class="form-groupe">
                <label for="identifiant">Adresse e-mail *</label>
                <input type="email" id="identifiant" name="identifiant"
                       value="<?php echo htmlspecialchars($_POST['identifiant'] ?? ''); ?>" required>
            </div>
            <div class="form-groupe">
                <label for="mot_de_passe">Choisissez un mot de passe (entre 4 et 60 caractères) *</label>
                <input type="password" id="mot_de_passe" name="mot_de_passe" required>
            </div>
            <div class="form-groupe">
                <label for="confirmation">Confirmer le mot de passe *</label>
                <input type="password" id="confirmation" name="confirmation" required>
            </div>
            <button type="submit" class="btn-complet">Créer un compte</button>
        </form>

        <form method="GET" action="index.php">
            <input type="hidden" name="action" value="login">
            <button type="submit" class="btn-complet secondaire">← Retour à la connexion</button>
        </form>
    </div>
</div>
</body>
</html>
