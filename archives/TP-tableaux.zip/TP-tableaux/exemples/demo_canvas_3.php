<!DOCTYPE html>
<html>
    <head>
        <title>Démo canvas 2</title>
        <meta charset="utf-8" />    
    </head>
    <body>

    <!-- voir https://developer.mozilla.org/en/Canvas_tutorial -->
    <!-- JS et PHP ensembles -->
    
<?php
function genererTableauAleatoire() {
    echo "new Array(";
    for ($i=0; $i<9; $i++) {
        echo rand(0, 20), ",";
    }
    echo rand(0, 20), ")";
}
?>


        <script type="application/javascript" >
            function dessiner() {
                let canevas = document.getElementById("canevas"); // canevas (toile) sur lequel on va dessiner
                let contexte = canevas.getContext("2d"); // "2d" et non pas "2D" !
                contexte.fillStyle = "rgb(180, 180, 180)";  // couleur RGB qui sera utilisé dans les dessins suivants
                contexte.fillRect (0, 0, canevas.width, canevas.height);  // dessin d'un rectangle de la taille du canevas

                //contexte.fillStyle = "rgb(100,0,0)";
                //let tab = new Array(12, 15, 7, 8, 13, 5, 20, 4, 19, 7); // un tableau de notes
                <?php echo "let tab =", genererTableauAleatoire(), ";"; ?>
                // parcours du tableau
                for (let i=0; i<9; i++) {
                    contexte.fillStyle = "rgba(30, " + (70+i*10) + ", " + (20+i*10) + ", 0.8)"; // couleur RGB avec transparence
                    contexte.fillRect(20+i*30, 20, 20, tab[i]*10);
                }
            }      
        </script>

    <canvas id="canevas" width="600" height="300"></canvas>

    <input id="bouton" type="button" value="Dessiner" onClick="dessiner()"/>

    </body>
</html>
