TEMPLATE = app
CONFIG += console c++17
CONFIG -= app_bundle
CONFIG -= qt

SOURCES += \
        ../LYCEE/personne.cpp \
        cours.cpp \
        enseignant.cpp \
        etudiant.cpp \
        main.cpp \
        ville.cpp

HEADERS += \
    ../LYCEE/personne.h \
    cours.h \
    enseignant.h \
    etudiant.h \
    ville.h
