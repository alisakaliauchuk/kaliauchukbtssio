#include "enseignant.h"
#include <iostream>
using namespace std;

enseignant::enseignant(string nom, string matiere, char sexe, float salaire, ville* v)
    : personne(nom, sexe)
{
    this->matiere = matiere;
    this->salaire = salaire;
    this->maVille = v;
}

void enseignant::setSexe(char s)
{
    personne::setSexe(s);
}

string enseignant::getNom()
{
    return this->nom;
}

string enseignant::getMatiere()
{
    return this->matiere;
}

void enseignant::afficher()
{
    cout << "Enseignant" << endl;
    personne::afficher();
    cout << "matière : " << this->matiere << endl;
    cout << "salaire : " << this->salaire << " €" << endl;
    if (this->maVille != nullptr)
        cout << "habite à " << this->maVille->nom << " (" << this->maVille->cp << ")" << endl;
}
