<?php
/**
 * index.php — Routeur frontal
 * Toutes les requêtes passent ici.
 * Structure :  ?page=navires&action=detail&id=42
 */

$page   = $_GET['page']   ?? 'home';
$action = $_GET['action'] ?? 'index';

// Sécurisation basique : on autorise uniquement des identifiants alphanumériques
$page   = preg_replace('/[^a-zA-Z0-9_]/', '', $page);
$action = preg_replace('/[^a-zA-Z0-9_]/', '', $action);

// ── Routage ────────────────────────────────────────────────────────────────
switch ($page) {

    case 'navires':
        require_once __DIR__ . '/C/NavireController.php';
        $ctrl = new NavireController();
        if ($action === 'detail') {
            $ctrl->detail();
        } else {
            $ctrl->index();
        }
        break;

    case 'escales':
        require_once __DIR__ . '/C/EscaleController.php';
        $ctrl = new EscaleController();
        if ($action === 'detail') {
            $ctrl->detail();
        } else {
            $ctrl->index();
        }
        break;

    case 'quais':
        require_once __DIR__ . '/C/QuaiController.php';
        $ctrl = new QuaiController();
        $ctrl->index();
        break;

    case 'home':
    default:
        $pageTitle = 'Accueil';
        require __DIR__ . '/V/home.php';
        break;
}
