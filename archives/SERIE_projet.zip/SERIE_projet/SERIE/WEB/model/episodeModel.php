<?php
require_once 'connexionBDD.php';

function getInfoEpisode($numSerie, $numSaison, $numEpi) {
    $pdo = connexionBDD();
    $req = $pdo->prepare('SELECT e.num_epi,e.num_saison,e.num_serie,s.titre_serievf
        FROM Episode e
        JOIN Serie s ON e.num_serie = s.num_serie
        WHERE e.num_serie  = :num_serie AND e.num_saison = :num_saison AND e.num_epi    = :num_epi');
    $req->execute([
        ':num_serie'  => $numSerie,
        ':num_saison' => $numSaison,
        ':num_epi'    => $numEpi
    ]);
    return $req->fetch();
}
