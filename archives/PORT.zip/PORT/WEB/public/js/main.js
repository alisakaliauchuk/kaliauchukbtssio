document.querySelectorAll('.data-table tbody tr').forEach(row => {
    row.addEventListener('click', function (e) {
        if (e.target.tagName === 'A' || e.target.tagName === 'BUTTON') return;
        const link = this.querySelector('a.btn-escale, a[href]');
        if (link) link.click();
    });
    row.style.cursor = 'pointer';
});