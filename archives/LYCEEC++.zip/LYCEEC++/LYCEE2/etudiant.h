#ifndef ETUDIANT_H
#define ETUDIANT_H
#include <vector>
#include "../LYCEE/personne.h"
#include "cours.h"
#include "ville.h"

class etudiant : public personne
{
private:

public:
    vector<cours*> tabCours;
    ville* maVille;
    string numcarte;

    etudiant(string nom, string num);
    void afficher();
    void setSexe(char s);
    void ajouterCours(cours* c);
    void afficherCours();
    string getNumcarte();
};

#endif // ETUDIANT_H
