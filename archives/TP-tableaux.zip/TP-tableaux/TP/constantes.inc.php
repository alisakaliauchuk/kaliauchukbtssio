<?php
// définition des constantes
define('SERVEUR', 'localhost'); // define permet de définir des constantes
define('PORT', '5432');

define('UTILISATEUR', 'squirrel');
define('MDP', 'slam'); // mot de passe
define('NOM_BASE', 'hotel');

define('DSN', 'pgsql:host=' . SERVEUR . ' port=' . PORT . ' dbname=' . NOM_BASE);