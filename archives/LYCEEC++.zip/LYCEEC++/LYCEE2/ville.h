#ifndef VILLE_H
#define VILLE_H
#include <string>

using namespace std;

class ville
{
public:
    string nom;
    string cp;

    ville(string nom, string cp);
};
#endif
