const LARGEUR = 1150;
const HAUTEUR = 150;
const NB_IMAGES = 20;
const TAILLE = 32;
const positionsX = [1150, 100, 150, 200]; 
const positionsY = [260, 120, 180, 240];

var canevas = document.getElementById('canevas'),
    contexte = canevas.getContext('2d'),
    etage = 0,
    carre,
    annulation = false,
    cote = canevas.offsetLeft,
    hauteur = canevas.offsetTop,
    x,
    y;

    let eventclick1 = function (event){
            x = event.pageX - cote;
            y = event.pageY - hauteur;
            if (x < 590 && x > 520 && y < 190 && y > 130) {
                choisirChambre("001");
                console.log("Bonjour");
            } else if (x < 590 && x > 520 && y < 270 && y > 210) {
                choisirChambre("002");
            } else if (x < 670 && x > 600 && y < 190 && y > 130) {
                choisirChambre("003");
            } else if (x < 670 && x > 600 && y < 270 && y > 210) {
                choisirChambre("004");
            } else if (x < 830 && x > 680 && y < 190 && y > 130) {
                choisirGChambre("005");
            } else if (x < 750 && x > 680 && y < 270 && y > 210) {
                choisirChambre("006");
            } else if (x < 830 && x > 760 && y < 270 && y > 210) {
                choisirChambre("007");
            } else if (x < 980 && x > 910 && y < 270 && y > 210) {
                choisirChambre("008");
            } else if (x < 980 && x > 910 && y < 190 && y > 130) {
                choisirChambre("009");
            } else if (x < 980 && x > 910 && y < 440 && y > 290) {
                choisirGChambre("010");
            } else if (x < 1110 && x > 1040 && y < 360 && y > 290) {
                choisirChambre("011");
            } else if (x < 1110 && x > 1040 && y < 440 && y > 370) {
                choisirChambre("012");
            } else if (x < 1110 && x > 910 && y < 530 && y > 460) {
                choisirGChambre("013");
            } else if (x < 1110 && x > 1040 && y < 270 && y > 130) {
                if (confirm("Voulez-vous de l'aide par rapport à une réservation?")) {
                    alert("Très bien, voici le numéro de la réception: *insérer numéro*");
                } else {
                    alert("Très bien, bonne journée!")
                };
            }
        };

    let eventclick2 = function (event){
        x = event.pageX - cote;
        y = event.pageY - hauteur;
        if (x < 590 && x > 520 && y < 190 && y > 130) {
            choisirChambre("101");
        } else if (x < 670 && x > 520 && y < 270 && y > 210) {
            choisirGChambre("103");
        } else if (x < 670 && x > 600 && y < 190 && y > 130) {
            choisirChambre("102");
        } else if (x < 750 && x > 680 && y < 190 && y > 130) {
            choisirChambre("104");
        } else if (x < 830 && x > 760 && y < 190 && y > 130) {
            choisirChambre("106");
        } else if (x < 750 && x > 680 && y < 270 && y > 210) {
            choisirChambre("105");
        } else if (x < 830 && x > 760 && y < 270 && y > 210) {
            choisirChambre("107");
        } else if (x < 980 && x > 910 && y < 270 && y > 210) {
            choisirChambre("109");
        } else if (x < 980 && x > 910 && y < 190 && y > 130) {
            choisirChambre("108");
        } else if (x < 980 && x > 910 && y < 360 && y > 290) {
            choisirChambre("111");
        } else if (x < 1110 && x > 1040 && y < 360 && y > 290) {
            choisirChambre("112");
        } else if (x < 1110 && x > 910 && y < 530 && y > 380) {
            choisirSuite("113");
        } else if (x < 1110 && x > 1040 && y < 270 && y > 130) {
            choisirGChambre("110");
        }
    };

    let eventclick3 = function (event){
        x = event.pageX - cote;
        y = event.pageY - hauteur;
        if (x < 660 && x > 520 && y < 270 && y > 130){
            choisirSuite("201");
        } else if (x < 840 && x > 680 && y < 190 && y > 130){
            choisirGChambre("202");
        } else if (x < 840 && x > 680 && y < 270 && y > 210){
            choisirGChambre("203");
        } else if (x < 980 && x > 910 && y < 190 && y > 130){
            choisirChambre("204");
        } else if (x < 980 && x > 910 && y < 270 && y > 210){
            choisirChambre("205");
        } else if (x < 1110 && x > 1040 && y < 270 && y > 130){
            choisirGChambre("206");
        } else if (x < 980 && x > 910 && y < 360 && y > 290){
            choisirChambre("207");
        } else if (x < 1110 && x > 1040 && y < 360 && y > 290){
            choisirChambre("208");
        } else if (x < 1110 && x > 910 && y < 530 && y > 380){
            choisirSuite("209");
        }
    };

    function envoyerReservation(nom, prenom, adresse, numero_tel, ville, num_chambre) {
        fetch('recherche.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nom: nom,
                prenom: prenom,
                adresse: adresse,
                numero_tel: numero_tel,
                ville: ville,
                num_chambre: num_chambre
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("Réservation réussie !");
            } else {
                alert("Erreur de réservation : " + data.message);
            }
        })
        .catch(error => {
            console.error("Erreur lors de l'envoi de la requête :", error);
        });
}

function choisirChambre(chambre) {
    const dateReservation = document.getElementById("dateReservation").value;
    if (!dateReservation) {
        alert("Veuillez sélectionner une date pour la réservation.");
        return;
    }

    if (!confirm("Vous avez décidé de choisir la chambre " + chambre + ", est-ce le cas?")) {
        alert("Très bien, bonne journée!");
        return;
    }

    let nom = prompt("Entrez votre nom :");
    if (nom === null) {
        alert("Réservation annulée.");
        return;
    }

    let prenom = prompt("Entrez votre prénom :");
    if (prenom === null) {
        alert("Réservation annulée.");
        return;
    }

    let adresse = prompt("Entrez votre adresse :");
    if (adresse === null) {
        alert("Réservation annulée.");
        return;
    }

    let numero_tel = prompt("Entrez votre numéro de téléphone :");
    if (numero_tel === null) {
        alert("Réservation annulée.");
        return;
    }

    let ville = prompt("Entrez votre ville :");
    if (ville === null) {
        alert("Réservation annulée.");
        return;
    }

    envoyerReservation(nom, prenom, adresse, numero_tel, ville, chambre, dateReservation);
    alert("Votre réservation avec la chambre " + chambre + " a été prise en compte et enregistrée dans la BDD.");
    console.log("Réservation faite");
}

function choisirGChambre(chambre) {
    choisirChambre(chambre);
}

function choisirSuite(chambre) {
    choisirChambre(chambre);
}

function chargerDisponibiliteChambres() {
    const dateVerification = document.getElementById("dateVerification").value;

    if (!dateVerification) {
        alert("Veuillez sélectionner une date pour vérifier la disponibilité.");
        return;
    }

    fetch('recherche.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ date: dateVerification })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            dessinerChambres(data.chambres);
        } else {
            console.error("Erreur lors du chargement de la disponibilité des chambres :", data.message);
        }
    })
    .catch(error => console.error("Erreur lors de la requête AJAX :", error));
}

function dessinerChambres(chambres) {
    const contexte = document.getElementById("canevas").getContext("2d");
    contexte.clearRect(0, 0, 1800, 800);

    chambres.forEach(chambre => {
        const couleur = chambre.statut == 'libre' ? 'green' : 'red';
        contexte.fillStyle = couleur;

        if (chambre.num_chambre == "001") {
            contexte.fillRect(520, 130, 70, 60);
        } else if (chambre.num_chambre == "002") {
            contexte.fillRect(520, 210, 70, 60);
        }else if (chambre.num_chambre == "003") {
            contexte.fillRect(600, 130, 70, 60);
        }else if (chambre.num_chambre == "004") {
            contexte.fillRect(600, 210, 70, 60);
        }else if (chambre.num_chambre == "005") {
            contexte.fillRect(680, 130, 140, 60);
        }else if (chambre.num_chambre == "006") {
            contexte.fillRect(680, 210, 70, 60);
        }else if (chambre.num_chambre == "007") {
            contexte.fillRect(680, 290, 70, 60);
        }
    });
}

for(let i=0; i<NB_IMAGES; i++) {
    const img = new Image();
    img.src = "images/sapin.png";
    img.onload = () => {
        // Vérifier si la position existe dans les tableaux
        let x = positionsX[i % positionsX.length];
        let y = positionsY[i % positionsY.length];
        
        // Dessiner l'image à la position définie
        contexte.drawImage(img, x, y, TAILLE, TAILLE);
    };
}

contexte.fillStyle = "rgb(230, 230, 230)";
contexte.strokeStyle = "black";
contexte.rect(400, 10, 1100, 100);
contexte.stroke();
contexte.fillRect(400, 10, 1100, 100);
contexte.fillStyle = "black";
contexte.font = "15pt Tahoma";
contexte.fillText("Rue", 900, 90);

//second tracé (parc)
contexte.fillStyle = "rgb(30, 230, 30)";
contexte.strokeStyle = "black";
contexte.rect(1150, 120, 300, 600);
contexte.stroke();
contexte.fillStyle = "black";
contexte.font = "15pt Tahoma";
contexte.fillText("Terrasse", 640, 350);

//quatrième tracé (piscine)
contexte.strokeStyle = "black";
contexte.rect(550, 400, 251, 121);
contexte.stroke();
contexte.fillStyle = "black";
contexte.font = "15pt Tahoma";
contexte.fillText("Piscine", 640, 510);

contexte.strokeStyle = "black";
contexte.beginPath();
contexte.moveTo(500, 120);
contexte.lineTo(1000, 120);
contexte.moveTo(1030, 120);
contexte.lineTo(1120, 120);
contexte.lineTo(1120, 550);
contexte.lineTo(900, 550);
contexte.lineTo(900, 280);
contexte.moveTo(870, 280)
contexte.lineTo(500, 280);
contexte.lineTo(500, 120);
contexte.stroke();


function effacer() {
    contexte.fillStyle = "white" // ne pas oublier les guillemets
    contexte.fillRect(501, 121, 619, 159);
    contexte.fillRect(900, 120, 219, 429);
}

function dessiner(numeroEtage) {
    effacer();
    if (numeroEtage === 1) {
        etage = 1;
        console.log("Nous sommes sur le RDC");
        contexte.beginPath();
        contexte.strokeStyle = "black";
        contexte.moveTo(500, 120);
        contexte.lineTo(1000, 120);
        contexte.moveTo(1030, 120);
        contexte.lineTo(1120, 120);
        contexte.lineTo(1120, 550);
        contexte.lineTo(900, 550);
        contexte.lineTo(900, 280);
        contexte.moveTo(870, 280)
        contexte.lineTo(500, 280);
        contexte.lineTo(500, 120);
        contexte.stroke();

        contexte.strokeStyle = "black";
        contexte.fillStyle = "grey";
        contexte.rect(1040, 130, 70, 140);
        contexte.stroke();
        contexte.fillRect(1040, 130, 70, 140);
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("Récep-", 1040, 180);
        contexte.fillText("tion", 1040, 200);

        contexte.rect(520, 130, 70, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.fillText("001", 530, 180);

        contexte.rect(520, 210, 70, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.fillText("002", 530, 260);

        contexte.rect(600, 130, 70, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.fillText("003", 610, 180);

        contexte.rect(600, 210, 70, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.fillText("004", 610, 260);

        contexte.rect(680, 130, 150, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.fillText("005", 720, 180);

        contexte.rect(680, 210, 70, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.fillText("006", 690, 260);

        contexte.rect(760, 210, 70, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.fillText("007", 770, 260);

        contexte.rect(910, 130, 70, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.fillText("009", 930, 180);

        contexte.rect(910, 210, 70, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.fillText("008", 930, 260);

        contexte.rect(910, 290, 70, 150);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.fillText("010", 920, 370);

        contexte.rect(910, 460, 200, 70);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.fillText("013", 990, 500);

        contexte.rect(1040, 290, 70, 70);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.fillText("011", 1060, 330);

        contexte.rect(1040, 370, 70, 70);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.fillText("012", 1060, 410);

    } else if (numeroEtage === 2) {
        etage = 2;
        console.log("Nous sommes sur l'étage " + (etage - 1));
        contexte.beginPath();
        contexte.strokeStyle = "black";
        contexte.moveTo(500, 120);
        contexte.lineTo(1000, 120);
        contexte.lineTo(1120, 120);
        contexte.lineTo(1120, 550);
        contexte.lineTo(900, 550);
        contexte.lineTo(900, 280);
        contexte.lineTo(500, 280);
        contexte.lineTo(500, 120);
        contexte.stroke();

        contexte.beginPath();
         
        contexte.strokeStyle = "black";
        contexte.rect(520, 130, 70, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("101", 530, 180);

        contexte.strokeStyle = "black";
        contexte.rect(600, 130, 70, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("102", 610, 180);

        contexte.strokeStyle = "black";
        contexte.rect(520, 210, 150, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("103", 580, 260);

        contexte.strokeStyle = "black";
        contexte.rect(680, 130, 70, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("104", 700, 180);

        contexte.strokeStyle = "black";
        contexte.rect(760, 130, 70, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("106", 780, 180);

        contexte.strokeStyle = "black";
        contexte.rect(680, 210, 70, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("105", 690, 260);

        contexte.strokeStyle = "black";
        contexte.rect(760, 210, 70, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("107", 780, 260);

        contexte.strokeStyle = "black";
        contexte.rect(910, 130, 70, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("108", 930, 180);

        contexte.strokeStyle = "black";
        contexte.rect(910, 210, 70, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("109", 930, 260);

        contexte.strokeStyle = "black";
        contexte.rect(910, 290, 70, 70);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("111", 930, 330);

        contexte.strokeStyle = "black";
        contexte.rect(1040, 290, 70, 70);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("112", 1060, 330);

        contexte.strokeStyle = "black";
        contexte.rect(910, 380, 200, 150);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("113", 990, 460);

        contexte.strokeStyle = "black";
        contexte.rect(1040, 130, 70, 140);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("110", 1060, 200);

    } else if (numeroEtage === 3){
        etage = 3;
        contexte.beginPath();
        console.log("Nous sommes sur l'étage "+ (etage - 1));
        contexte.strokeStyle = "black";
        contexte.moveTo(500, 120);
        contexte.lineTo(1000, 120);
        contexte.lineTo(1120, 120);
        contexte.lineTo(1120, 550);
        contexte.lineTo(900, 550);
        contexte.lineTo(900, 280);
        contexte.lineTo(500, 280);
        contexte.lineTo(500, 120);
        contexte.stroke();

        contexte.strokeStyle = "black";
        contexte.rect(520, 130, 150, 140);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("201", 580, 210);

        contexte.strokeStyle = "black";
        contexte.rect(680, 130, 160, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("202", 750, 170);

        contexte.strokeStyle = "black";
        contexte.rect(680, 210, 160, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("203", 750, 250);

        contexte.strokeStyle = "black";
        contexte.rect(910, 210, 70, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("205", 930, 260);

        contexte.strokeStyle = "black";
        contexte.rect(910, 130, 70, 60);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("204", 930, 180);

        contexte.strokeStyle = "black";
        contexte.rect(1040, 130, 70, 140);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("206", 1060, 200);

        contexte.strokeStyle = "black";
        contexte.rect(910, 290, 70, 70);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("207", 930, 330);

        contexte.strokeStyle = "black";
        contexte.rect(1040, 290, 70, 70);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("208", 1060, 330);

        contexte.strokeStyle = "black";
        contexte.rect(910, 380, 200, 150);
        contexte.stroke();
        contexte.fillStyle = "black";
        contexte.font = "15pt Tahoma";
        contexte.fillText("209", 990, 460);
    }

    if (etage == 1) {
        canevas.addEventListener('click', eventclick1);
    } else if (etage == 2) {
        canevas.addEventListener('click', eventclick2);
    } else if (etage == 3){
        canevas.addEventListener('click', eventclick3);
    }

    if (numeroEtage === 1 && eventclick2){
        canevas.removeEventListener('click', eventclick2);
    }
    if (numeroEtage === 1 && eventclick3){
        canevas.removeEventListener('click', eventclick3);
    }
    if (numeroEtage === 2 && eventclick1){
        canevas.removeEventListener('click', eventclick1);
    }
    if (numeroEtage === 2 && eventclick3){
        canevas.removeEventListener('click', eventclick3);
    }
    if (numeroEtage === 3 && eventclick1){
        canevas.removeEventListener('click', eventclick1);
    }
    if (numeroEtage === 3 && eventclick2){
        canevas.removeEventListener('click', eventclick2);
    }
}

function afficherimagepiscine() {
    var canvas = getElementById("canvas");
    var ctx = canvas.getContext("2d");

    var image = new Image();
    image.src = 'images/piscine.jpg';
    image.onload = function(){
        ctx.drawImage(image, 550, 400, 250, 120);
    };
    image.onerror = function (){
        console.log("Erreur de chargement de l'image.");
    };
}

afficherimagepiscine();


//tracé de sapin
/*for (let i = 0; i < NB_IMAGES; i++) {
    const img = new Image();
    img.src = "images/sapin.png";
    let l = 600;
    let f = 600;
    let x = l;
    let y = f;
    for (a = 0; a < 3; a++){
        l = l + 30;
        f = f + 30;
        if (a == 3){
            a = 0;
            f = 600;
        }
    }
}*/