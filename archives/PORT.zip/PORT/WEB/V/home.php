<?php
$pageTitle = 'Accueil';
require __DIR__ . '/layout/header.php';
?>

<div class="home-hero">
    <h1>Bienvenue sur le portail du<br><strong>Port de Caen-Ouistreham</strong></h1>
    <p>Consultez la liste des navires, leurs escales et l'organisation des quais.</p>
</div>

<div class="home-cards">
    <a href="index.php?page=navires" class="home-card">
        <div class="home-card-icon">🚢</div>
        <div class="home-card-title">Navires</div>
        <div class="home-card-desc">Liste complète des navires, caractéristiques et historique d'escales.</div>
    </a>
    <a href="index.php?page=escales" class="home-card">
        <div class="home-card-icon">⚓</div>
        <div class="home-card-title">Escales</div>
        <div class="home-card-desc">Toutes les escales enregistrées avec détails pilotes, fret et confirmation.</div>
    </a>
    <a href="index.php?page=quais" class="home-card">
        <div class="home-card-icon">🏗</div>
        <div class="home-card-title">Quais &amp; Postes</div>
        <div class="home-card-desc">Organisation des quais, postes d'amarrage et types de fret autorisés.</div>
    </a>
</div>

<?php require __DIR__ . '/layout/footer.php'; ?>
