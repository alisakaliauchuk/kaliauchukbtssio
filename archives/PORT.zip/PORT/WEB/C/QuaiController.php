<?php
require_once __DIR__ . '/../M/QuaiModel.php';

class QuaiController {

    private QuaiModel $model;

    public function __construct() {
        $this->model = new QuaiModel();
    }

    public function index(): void {
        $quaisPostes = $this->model->getQuaisPostes();
        $quaisFret   = $this->model->getQuaisFret();
        $pageTitle   = 'Quais & Postes';
        require __DIR__ . '/../V/quai/liste.php';
    }
}
