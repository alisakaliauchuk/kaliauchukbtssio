DELIMITER $$
CREATE TRIGGER verifUtilisateur
BEFORE INSERT ON Utilisateur
FOR EACH ROW
BEGIN

IF EXISTS (
    SELECT 1
    FROM Utilisateur
    WHERE identifiant = NEW.identifiant
    AND mot_de_passe = NEW.mot_de_passe
)
THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Utilisateur deja existant';
END IF;

END$$

DELIMITER ;